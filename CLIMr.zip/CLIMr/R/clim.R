#' NARCCAP CLIMATE DAT SWAT CONVERSION MODEL
#' @export
mainCode <- function(){

######NARCCAP CLIMATE DAT SWAT CONVERSION MODEL ######
clim_swat_convert<- function(var1_wd,var2_gpinfo,var3a_hfl,var3b_ffl,var4a_hcdf, var4b_fcdf,var5a_nvhi,var5b_nvfu,  var6a_nfhi, var6b_nffu, var7_opfp,var8a_ofhi,var8b_offu,var9_opstn){

  #######NEEDS TO CHANGE ########set-theworkingdirectory###
  setwd(var1_wd)
  rcmwshedgpi<- read.table(var2_gpinfo, header=T) # rcmwshedgpi - Watershed-gridpoints info
  numgp <- nrow(rcmwshedgpi)   # numgp <- NUMber of Grid Points
  nvar  <- ncol(rcmwshedgpi)   # nvar- Number of VARiables in the grid point file
  varnames <- scan(var2_gpinfo, what=" ", nlines =1) # varnames-variable names in the lat long table
  # assigning the varible names with the corrsponding values of lat-long text file
  for (j in 1:nvar)
  {
    assign(varnames[j],rcmwshedgpi[,j])
  }
  #reading the netcdfdata of temperature and precipitation#
  library(ncdf4)
  library(chron)
  # Number of data sets for program run - Either Present or Future -1; Both Present and future-2
  datasets <- c(var3a_hfl,var3b_ffl) #Files containing the present and future files
  ndsets   <-	length(datasets)
  filefolder<-c(var4a_hcdf,var4b_fcdf) #Folder names containing present and future files
  numvarinfiles     <-c(var5a_nvhi,var5b_nvfu)   # Number of variables in each file list
  numfileeachvar    <-c(var6a_nfhi,var6b_nffu)   # Number of files for each variable in the file list
  outputfilepath<-var7_opfp
  opfilefolder<-c(var8a_ofhi,var8b_offu) #Output Folder names containing present and future files
  #giving the file name to the tempfiles and rainfall
  nasstpc <- var9_opstn  # nasttemp- Name of the Sub String for the Temperature and Precipitation files
  #########NEEDS TO CHANGE ###########
  # Reading the file list of temperature and precipitation names for present and future
  for(drun in 1:ndsets)   # ndsets
  {
    filevarnames <- scan(datasets[drun], what=" ", nlines =-1) # File Varaible Names- netCDF- Files of All Files variable names in the file list
    tnumfiles<-length(filevarnames)
    filepathvar<-paste(filefolder[drun],"\\", sep="")
    nfile<-numfileeachvar[drun]
    fpr<-(1:nfile)     #filename array for precipitation
    ftasmax<-(1:nfile) #filename array for maximim temperature
    ftasmin<-(1:nfile) #filename array for minimum temperature
    #Saving the filenames and path for each variable

    for(f in 1:nfile)
    {
      fpr[f]<-paste(filepathvar,filevarnames[f],sep="")
      ftasmax[f]<-paste(filepathvar,filevarnames[f+nfile],sep="")
      ftasmin[f]<-paste(filepathvar,filevarnames[f+2*nfile],sep="")
    }
    dir.create(file.path(outputfilepath,opfilefolder[drun]),showWarnings = FALSE)
    op_folderpath<-paste(outputfilepath,"\\",opfilefolder[drun],"/",sep="")
    op_filelist<-paste(op_folderpath,opfilefolder[drun],"_","fi_list",".txt",sep="")
    # Reading the files for each variable from their location
    for(f in 1:nfile)
    {
      ntasmaxk <- nc_open(ftasmax[f])
      ntasmink <- nc_open(ftasmin[f])
      npcp     <- nc_open(fpr[f])
      ntime    <- ncvar_get(ntasmaxk,"time")      #Creating the vector of timesteps
      ntimep   <- ncvar_get(npcp,"time")          #Creating the vector of timesteps
      # creating dates and time steps information
      stdatest<-ncatt_get(ntasmaxk,"time","units")$value
      y<-as.numeric(substring(stdatest,12,15))
      m<-as.numeric(substring(stdatest,17,18))
      d<-as.numeric(substring(stdatest,20,21))
      data_stdate<-dates(ntime[1],origin=c(month=m,day=d,year=y))
      sty<-as.numeric(substring(as.Date(data_stdate),1,4))
      if(y==sty)
      {
        CLYF<-0
      } else
      {
        CLYF<-sum(leap.year(y:sty))
      }
      tdates <- dates(ntime,origin=c(month=m,day=d+CLYF,year=y))
      tsteps <- length(ntime)
      ## Creating dates and time steps for precipitation
      stdatestp<-ncatt_get(npcp,"time","units")$value
      yp<-as.numeric(substring(stdatest,12,15))
      mp<-as.numeric(substring(stdatest,17,18))
      dp<-as.numeric(substring(stdatest,20,21))
      data_stdate_p<-dates(ntimep[1],origin=c(month=mp,day=dp,year=yp))
      sty_p<-as.numeric(substring(as.Date(data_stdate),1,4))
      if(yp==sty_p)
      {
        CLYF<-0
      } else
      {
        CLYF<-sum(leap.year(yp:sty_p))
      }
      tdates_p <- dates(ntimep,origin=c(month=mp,day=dp+CLYF,year=yp))
      tsteps_p <-length(ntimep)
      if(data_stdate_p==data_stdate)
      {
        tini<-1
        tstvalue<-1
        print(tini)
      } else if(data_stdate_p > data_stdate) {
        tini <-data_stdate_p - data_stdate + 1
        tini<-as.numeric(tini)
        tstvalue<-1
        print(tini)
      } else
      {
        tini <-data_stdate - data_stdate_p + 1
        tini<-as.numeric(tini)
        print(tini)
        tstvalue<-tini
      }
      ########## Time steps of PCP and temperature check ##################
      if(f==1)
      {
        if(nfile!=1)
        {
          lntasmaxk<- nc_open(ftasmax[nfile])
          lntime   <- ncvar_get(lntasmaxk,"time")
          ltsteps  <- length(lntime)
          data_endate_leapless<-dates(lntime[ltsteps],origin=c(month=m,day=d,year=y))
          endy_leapless<-as.numeric(substring(as.Date(data_endate_leapless),1,4))
          TCLYF<-sum(leap.year(y:endy_leapless))
          data_endate<-dates(lntime[ltsteps],origin=c(month=m,day=d+TCLYF,year=y))
          endy<-as.numeric(substring(as.Date(data_endate),3,4))
        }
        else
        {
          data_endate<-dates(ntime[tsteps],origin=c(month=m,day=d+CLYF,year=y))
          endy<-as.numeric(substring(as.Date(data_endate),3,4))
        }
      }
      st_sy<- substring(as.Date(data_stdate),1,4)
      st_ey<- substring(as.Date(data_endate),3,4)
      #information on precipitation files data interval
      data_coll_intval <- 3 # data collection time intervals per day
      data_div_day     <- 24/data_coll_intval #data divisions per day
      #To store the swat inputfile for first variable
      if(f==1)
      {
        #file names to store data of temp, precipitation and grid information
        swttmpfiname<-paste(op_folderpath,nasstpc,"t",st_sy,"to",st_ey,".txt", sep="")
        swtpcpfiname<-paste(op_folderpath,nasstpc,"p",st_sy,"to",st_ey,".txt", sep="")
        # This to write the SWAT station inputfile first line
        swatipfl<-paste("ID", ",","NAME", ",","LAT",",", "LONG", ",","ELEVATION", sep ="")
        # Creating SWAT input table variables
        SID  <- (1:numgp)    # Station ID - To give one sequence of numbers
        NAME <- (1:numgp)    # Station Name
        LAT  <- (1:numgp)    # LATitude of grid points from NETCDF
        LONG <- (1:numgp)    # LONGitude of grid points from NETCDF
        ELEV <- (1:numgp)    # Elevation of grid points from GIS      ### Elevation from GIS folder
        print("13")
        # Variables assignment from .ncdf file
        for(i in 1:numgp)
        {
          SID[i] <- i
          NAME[i]<- paste(nasstpc,st_sy,"to", st_ey, "_", xc[i],".", yc[i],sep="")
          X=xc[i]
          print(X)
          Y=yc[i]
          print(Y)
          LAT[i]  <- ncvar_get(ntasmaxk,varid='lat',start=c(X+1,Y+1),count=c(1,1))
          print(LAT[i])
          LONG[i] <- ncvar_get(ntasmaxk,varid='lon',start=c(X+1,Y+1),count=c(1,1))- 360
          print(LONG[i])
          ELEV[i] <- Elevation[i]       ## Elevation from text file
          print(ELEV[i])
        }
        print("14")
        # Creating the SWAT inputfile for temperatute stations
        write(swatipfl, file=swttmpfiname, append ="False")
        for(i in 1:numgp)
        {
          tmpinfo<-paste(SID[i],",",NAME[i],",",round(LAT[i],3),",",round(LONG[i],3),",", round(ELEV[i],3),sep = "")
          write(tmpinfo,file=swttmpfiname, append = "TRUE")
        }
        #creating the inputfiles for min and max temperatures for each temperature station
        tmpflis<-(1:numgp)
        datedatfnamelist<- (1:numgp)
        datedatflist<-(1:numgp) # File name for date data files
        for(i in 1: numgp)
        {
          tmpflis[i]<- paste(op_folderpath, NAME[i], "t.txt", sep="")
          datedatfnamelist[i] <-paste(NAME[i],"datedat",".txt", sep="")
          write(datedatfnamelist[i],file=op_filelist, append = "TRUE")
          datedatflist[i]<-paste(op_folderpath,datedatfnamelist[i], sep="")
        }
      } # closing for the if condition for f=1 for temperature file
      print("15")
      if(f==1)
      {
        # Variables assignment from .ncdf file
        for(i in 1:numgp)
        {
          SID[i]<- i
          NAME[i]<- paste(nasstpc,st_sy,"to", st_ey,"_", xc[i],".",yc[i],sep= "")
          X=xc[i]
          Y=yc[i]
          LAT[i] <-  ncvar_get(npcp,varid='lat',start=c(X+1,Y+1),count=c(1,1))
          LONG[i] <- ncvar_get(npcp,varid='lon',start=c(X+1,Y+1),count=c(1,1))- 360 # To keep same format as swat
          ELEV[i] <- Elevation[i]       ## Elevation from text file
        }
        # Creating the SWAT inputfile for precipitation stations
        write(swatipfl, file=swtpcpfiname, append ="False")
        for(i in 1:numgp)
        {
          pcpinfo<-paste(SID[i],",",NAME[i],",",round(LAT[i],3),",",round(LONG[i],3), ",",round(ELEV[i],3),sep = "")
          write(pcpinfo,file=swtpcpfiname, append = "TRUE")
        }
        print("16")
        #creating the inputfiles for precipitation for station
        pcpflis<-(1:numgp)

        for(i in 1: numgp)
        {
          pcpflis[i]<- paste(op_folderpath, NAME[i], "pcp.txt", sep = "")
        }
      } # close for if loop for first precipitation file

      if(f==1)
      {
        startline<-paste("DATE",",","YEAR",",","MONTH",",","DAY", ",", "MaxTemp(C)", ",", "MinTemp(C)", "," ,"Precipitation(mm)", sep="") #Modified on 031113
        firstday<- as.Date(tdates[tini])   # Corrected to add the starting date;First day of the starting file of the work
        fi1stline<- paste(substring(firstday,1,4),substring(firstday,6,7),substring(firstday,9,10),sep="")        # SWAT input format to mention the starting year
      }
      print("17")
      #Writing data to individual files
      for(i in 1:numgp)
      {
        if(f==1)
        {
          write(fi1stline, file=pcpflis[i], append ="False")
          write(fi1stline, file=tmpflis[i], append ="False")
          write(startline, file=datedatflist[i], append ="False")
        }
        LYF<-0            # leap year factor
        tstart<- tstvalue # changed to accomodate different dates of temp and pcp files
        X=xc[i]
        Y=yc[i]
        for(t in tini:tsteps) # changed to accomodate different dates of temp and pcp files
        {
          if(days(tdates[t]+LYF)==29&&months(tdates[t]+LYF)=="Feb")
          {
            #To convert temperature from Kelvin to celsius "-273.15" is used
            tasmaxc <-ncvar_get(ntasmaxk,"tasmax",start=c(X+1,Y+1,t),count=c(1,1,1))-273.15
            tasminc <-ncvar_get(ntasmink,"tasmin",start=c(X+1,Y+1,t),count=c(1,1,1))-273.15
            swttemp<-paste(round(tasmaxc,1),",",round(tasminc,1), sep="")
            #tasmaxpdc-prvious day-max temperature
            tasmaxpdc<-ncvar_get(ntasmaxk,"tasmax",start=c(X+1,Y+1,t-1),count=c(1,1,1))-273.15
            tasminpdc<-ncvar_get(ntasmink,"tasmin",start=c(X+1,Y+1,t-1),count=c(1,1,1))-273.15
            ld_tasmaxc<- (tasmaxc +tasmaxpdc)/2
            ld_tasminc<- (tasminc +tasminpdc)/2
            swttempld<-paste(round(ld_tasmaxc,1),",",round(ld_tasminc,1), sep="")
            #Rainfalldata reading
            pcpdaycum<-ncvar_get(npcp,"pr",start=c(X+1,Y+1,tstart),count=c(1,1,data_div_day))
            pcpday<-sum(pcpdaycum)*10800  # to get total pr in mm per 3 hour
            #Previousday Precipitation
            dayless<-tstart-data_div_day
            pcpdlesscum<-ncvar_get(npcp,"pr",start=c(X+1,Y+1,dayless),count=c(1,1,data_div_day))
            pcpdayless<-sum(pcpdlesscum)*10800 #to get total pr in mm per 3 hour
            ld_pcpday<-(pcpday+pcpdayless)/2
            ld_pcpday<-round(ld_pcpday,1)
            write(ld_pcpday,file=pcpflis[i], append="TRUE")
            pcpday<-round(pcpday,1)
            write(pcpday,file=pcpflis[i], append="TRUE")
            write(swttempld, file=tmpflis[i], append ="TRUE")
            write(swttemp,   file=tmpflis[i], append ="TRUE")
            cdate<-as.Date(tdates[t])+LYF
            #datedata<-paste(t,",",cdate,",",round(ld_tasmaxc,1),",", round(ld_tasminc,1),",", ld_pcpday, sep="")
            date_y <- as.numeric(substring(cdate,1,4))
            date_m <- as.numeric(substring(cdate,6,7))
            date_d <- as.numeric(substring(cdate,9,10))
            datedata<-paste(cdate,",",date_y,",",date_m,",",date_d,",",round(ld_tasmaxc,1),",", round(ld_tasminc,1),",", ld_pcpday, sep="")
            write(datedata, file=datedatflist[i], append ="TRUE")
            LYF=LYF+1
            cdate<-as.Date(tdates[t])+LYF
            date_y <- as.numeric(substring(cdate,1,4))
            date_m <- as.numeric(substring(cdate,6,7))
            date_d <- as.numeric(substring(cdate,9,10))
            datedata<-paste(cdate,",",date_y,",",date_m,",",date_d,",",round(tasmaxc,1),",",round(tasminc,1),",", pcpday, sep="")
            write(datedata, file=datedatflist[i], append ="TRUE")
            tstart <- (t-tini+1)*data_div_day+1
            print("18")
          }
          else
          {
            # To convert temperature from Kelvin to celsius "-273.15" is used
            tasmaxc <-ncvar_get(ntasmaxk,"tasmax",start=c(X+1,Y+1,t),count=c(1,1,1))-273.15
            tasminc <-ncvar_get(ntasmink,"tasmin",start=c(X+1,Y+1,t),count=c(1,1,1))-273.15
            swttemp<-paste(round(tasmaxc,1),",",round(tasminc,1), sep="")
            write(swttemp,   file=tmpflis[i], append ="TRUE")
            pcpdaycum<-ncvar_get(npcp,"pr",start=c(X+1,Y+1,tstart),count=c(1,1,data_div_day))
            pcpday<-sum(pcpdaycum)*10800  # to get total pr in mm per 3 hour
            pcpday<-round(pcpday,1)
            write(pcpday,file=pcpflis[i], append="TRUE")
            cdate<-as.Date(tdates[t])+LYF
            date_y <- as.numeric(substring(cdate,1,4))
            date_m <- as.numeric(substring(cdate,6,7))
            date_d <- as.numeric(substring(cdate,9,10))
            datedata<-paste(cdate,",",date_y,",",date_m,",",date_d,",",round(tasmaxc,1),",",round(tasminc,1),",",pcpday, sep="")
            write(datedata, file=datedatflist[i], append ="TRUE")
            tstart <- (t-tini+1)*data_div_day+1  # added the correction to account late starting of rainfall file
          }


        }   # Close for time loops

      }    # Close for grid point loop

      # CLYF<-CLYF+LYF   # Adding the cumulative leaf year factor for the each period

    }  # Close for "nfile"  for number of variables for file

  } # Close for "drun" for nuber of data runs


  return()

} # Close for the function call

print("19")
############################# NARCCAP CLIM-SWAT CONVERSION MODEL ############################################################
# Program for Getting data for all the years of CMIP5 data for all models for the downloaded proejctions
# Date 13/11/2013
# Data dividing into different parts 1954- 2010; 2011-2070;
# DataSingle file run concept
# Output files format in the form of SWAT (Two files each for precipitation and Temperature, Present and Future//)
# One general file showing the outputs along with time step in csvformat.
# Seperate file generation for time and corrsponding outputs
# New concept is added to select only the rquired grid points whic fall within the watershed

################################# INPUT GIVING AREA ##########################################
library(ncdf4)
library(chron)
library(stringr)
cmip_tool<-function(var1,var2,var3,var4,var5,var6,var7,var8,var9){
  # set-theworkingdirectory
  setwd(var1)
  # scanning of prjections list
  projnamelis<-scan(var2,what=" ", nlines =-1) #List of all projections


  # Projections to be simulated
  x<-var3
  y<-str_extract_all(x,"\\(?[0-9]+\\)?")[[1]]
  simproj<-as.numeric(y)
  nsimproj<-length(simproj)

  # watershed name to come in file extensions
  wshedname<-var4  # two to four letters in shortened form for the watershed name

  # Gridpoint number list and elevation information for the watershed to the program

  ws_gpdata <- read.table(var5,header=T)  # watershed grid points
  nwsgp <- nrow(ws_gpdata) #number of grid points influencing the watershed
  FID  <- ws_gpdata$FID
  ELVE <- ws_gpdata$Elevation

  # Creation of file path for output **Seperate folders for each projection **textfile containing all the file names
  commonfilepath<-var9
  ###########INPUT GIVING AREA ###########
  ntasmax<-open.ncdf(var6)
  ntasmin<-open.ncdf(var7)
  npcp<-open.ncdf(var8)
  ntime <- get.var.ncdf(ntasmax,"time")
  stdatest<-att.get.ncdf(ntasmax,"time","units")$value #Getting the origin in the netcdf file
  #projection-names attachment
  nproject <- get.var.ncdf(ntasmax,"projection")  #Getting the projection variable
  totproj<- length(nproject)  # total different projections in CMIP5

  #Preparing the origin date
  y<-as.numeric(substring(stdatest,12,15))
  m<-as.numeric(substring(stdatest,17,18))
  d<-as.numeric(substring(stdatest,20,21))
  #Preparing all the dates
  tdates <- dates(ntime,origin=c(month=m,day=d,year=y))
  tsteps <-length(ntime)
  data_stdate<-dates(ntime[1],origin=c(month=m,day=d,year=y))
  sty<-as.numeric(substring(as.Date(data_stdate),1,4))

  ####### TIME PERIODS INPUT ########
  # Data grouping time periods for simulations,Ex: present, future-1,future-2,future-3)
  # First Start date should not be less than 01/01/1950; Last Sim End date should not be more than 12/31/2099
  nsimtperiod<-2 # Number of simulation time periods
  sim1stdate <- dates("01/01/1950",origin=c(month=m,day=d,year=y))# period 1-Historic; Date format MM/DD/YYYY
  sim1eddate <- dates("12/31/2010",origin=c(month=m,day=d,year=y))# period 1-Historic; Date format MM/DD/YYYY
  sim2stdate <- dates("01/01/2011",origin=c(month=m,day=d,year=y))# period 2-Future Date format MM/DD/YYYY
  sim2eddate  <- dates("12/31/2099",origin=c(month=m,day=d,year=y))# period 2-Future data format MM/DD/YYYY
  ################### TIME PERIODS INPUT#################################################

  tstsim1 <- as.numeric((sim1stdate-data_stdate)+1)
  tendsim1<- as.numeric((sim1eddate-data_stdate)+1)
  tstsim2 <- as.numeric((sim2stdate-data_stdate)+1)
  tendsim2<- as.numeric((sim2eddate-data_stdate)+1)
  stysim  <- c(substring(as.Date(sim1stdate),1,4),substring(as.Date(sim2stdate),1,4))
  endysim <- c(substring(as.Date(sim1eddate),1,4),substring(as.Date(sim2eddate),1,4))
  simsttime  <-c(tstsim1, tstsim2)
  simendtime <-c(tendsim1,tendsim2)

  #Getting the longitude and latitude values
  nlon <- get.var.ncdf(ntasmax,"longitude")
  nlat <- get.var.ncdf(ntasmax,"latitude")
  totlon<- length(nlon)
  totlat<- length(nlat)
  numgp <-totlon*totlat


  #start of projections loop
  for(proj in 1:nsimproj)
  {
    #Assigning the projection number
    p <-  simproj[proj]
    #giving the file name to the tempfiles and rainfall
    cmip5tpc <- paste(wshedname,"_",projnamelis[simproj[proj]],sep="") # nasttemp- Name of the Sub String for the Temperature and Precipitation files
    #creating the folder path for each projection
    dir.create(file.path(commonfilepath,projnamelis[simproj[proj]]),showWarnings = FALSE)
    proj_folderpath<-paste(commonfilepath,"/",projnamelis[simproj[proj]],"/",sep="")
    proj_filelist<-paste(commonfilepath,"/",projnamelis[simproj[proj]],"/",cmip5tpc,"_","filelist",".txt",sep="")
    #start of the for loop for the simulation periods
    for(simpd in 1: nsimtperiod)
    {
      tst<-simsttime[simpd]
      tend<-simendtime[simpd]
      swttmpfiname<-paste(proj_folderpath,cmip5tpc,"tmp",stysim[simpd],"to",endysim[simpd],".txt", sep="")
      swtpcpfiname<-paste(proj_folderpath,cmip5tpc,"pcp",stysim[simpd],"to",endysim[simpd],".txt", sep="")
      # This to write the SWAT station inputfile first line
      swatipfl<-paste("ID", ",","NAME", ",","LAT",",", "LONG",",", "ELEVATION", sep ="") #SWAT INPUT file First Line
      # Creating SWAT input table variables
      ID  <-  (1:numgp)    # Station ID - To give sequence of numbers for the grid
      NAME <- (1:nwsgp)    # Station Name
      LAT  <- (1:nwsgp)    # LATitude of grid points from NETCDF
      LONG <- (1:nwsgp)    # LONGitude of grid points from NETCDF
      # Variables assignment from .ncdf file
      rf<-1    # rotating factor to move from one row of cells(columns)to next row
      wsrf<-1  # rotating factor for climate grid points present in the watershed
      for(i in 1:totlat)
      {
        for(k in 1:totlon)
        {
          ID[k+rf-1]<- k+rf-1
          if(wsrf<=nwsgp)
          {
            if(ID[k+rf-1]==FID[wsrf])
            {
              NAME[wsrf]<- paste(cmip5tpc,"_", stysim[simpd],"to", endysim[simpd], "_gp",k+rf-1,sep="")
              LAT[wsrf] <- nlat[i]
              LONG[wsrf] <-nlon[k] - 360 # To keep same format as swat
              wsrf<- wsrf+1
            }
          }
          else{ break}

        }
        rf=rf+totlon
        if(wsrf>nwsgp)
        {
          break
        }
      }

      # Creating the SWAT inputfile for temperatute stations
      write(swatipfl, file=swttmpfiname, append ="False")
      for(i in 1:nwsgp)
      {
        tmpinfo<-paste(ID[i],",",NAME[i],",",round(LAT[i],3),",",round(LONG[i],3),",", round(ELVE[i],3),sep = "")
        write(tmpinfo,file=swttmpfiname, append = "TRUE")
      }


      #creating the inputfiles for min and max temperatures for each temperature station
      tmpflis<-(1:nwsgp)
      datedatflist<-(1:nwsgp) # File name for date data files
      for(i in 1: nwsgp)
      {
        tmpflis[i]<- paste(proj_folderpath,NAME[i], "t.txt", sep="")
        datedatfiname <- paste(NAME[i],"tpd",".csv", sep="")
        datedatflist[i]<-paste(proj_folderpath,datedatfiname, sep="")
        write(datedatfiname,file=proj_filelist, append = "TRUE")
      }

      # Variables assignment from .ncdf file for Precipitation
      rf<-1    #rotating factor two move from one row of cells(columns)to next row
      wsrf<-1  # rotating factor for climate grid points present in the watershed
      for(i in 1:totlat)
      {
        for(k in 1:totlon)
        {
          ID[k+rf-1]<- k+rf-1
          if(wsrf<=nwsgp)
          {

            if(ID[k+rf-1]==FID[wsrf])
            {
              NAME[wsrf] <- paste(cmip5tpc,"_", stysim[simpd],"to", endysim[simpd], "_gp",k+rf-1,sep="")
              LAT[wsrf]  <- get.var.ncdf(npcp,"latitude",start=c(i),count=c(1))
              LONG[wsrf] <- get.var.ncdf(npcp,"longitude",start=c(k),count=c(1))- 360 # To keep same format as swat
              wsrf<-wsrf+1
            }
          }
          else{ break}

        }
        rf=rf+totlon
        if(wsrf>nwsgp)
        {
          break
        }
      }

      #Creating the SWAT inputfile for precipitation stations
      write(swatipfl, file=swtpcpfiname, append ="False")
      for(i in 1:nwsgp)
      {
        pcpinfo<-paste(ID[i],",",NAME[i],",",round(LAT[i],3),",",round(LONG[i],3),",",round(ELVE[i],3), sep = "")
        write(pcpinfo,file=swtpcpfiname, append = "TRUE")
      }
      #creating the inputfiles for precipitation for station
      pcpflis<-(1:nwsgp)

      for(i in 1: nwsgp)
      {
        pcpflis[i]<- paste(proj_folderpath,NAME[i], "p.txt", sep = "")
      }


      secondline<-paste("DATE", ",", "YEAR", ",", "MONTH",",", "DAY",",", "MaxTemp(C)", ",", "MinTemp(C)", "," ,"Precipitation(mm)", sep="")
      startline<-paste("#",projnamelis[simproj[proj]],sep="")
      firstday<- as.Date(tdates[tst])   # First day of the starting file of the work
      fi1stline<- paste(substring(firstday,1,4),substring(firstday,6,7),substring(firstday,9,10),sep="")        # SWAT input format to mention the starting year

      rf<-1
      wsrf<-1  # rotating factor for climate grid points present in the watershed

      for(i in 1:totlat)
      {
        for(j in 1:totlon)
        {

          ID[j+rf-1]<- j+rf-1
          if(wsrf<=nwsgp)
          {

            if(ID[j+rf-1]==FID[wsrf])
            {

              write(fi1stline, file=pcpflis[wsrf], append ="False")
              write(fi1stline, file=tmpflis[wsrf], append ="False")
              write(startline, file=datedatflist[wsrf], append ="False")
              write(secondline, file=datedatflist[wsrf], append ="TRUE")
              for(t in tst:tend)
              {
                swpre  <- get.var.ncdf(npcp,"pr",start=c(j,i,t,p),count=c(1,1,1,1))
                swtmax <- get.var.ncdf(ntasmax,"tasmax",start=c(j,i,t,p),count=c(1,1,1,1))
                swtmin <- get.var.ncdf(ntasmin,"tasmin",start=c(j,i,t,p),count=c(1,1,1,1))
                swttemp<-paste(round(swtmax,1),",",round(swtmin,1), sep="")
                write(swttemp,   file=tmpflis[wsrf], append ="TRUE")
                swpre<-round(swpre,1)
                write(swpre,file=pcpflis[wsrf], append="TRUE")
                cdate<-as.Date(tdates[t])
                date_y <- as.numeric(substring(cdate,1,4))
                date_m <- as.numeric(substring(cdate,6,7))
                date_d <- as.numeric(substring(cdate,9,10))
                datedata<-paste(cdate,",",date_y,",",date_m ,",",date_d,",",round(swtmax,1),",",round(swtmin,1),",",swpre, sep="")
                write(datedata, file=datedatflist[wsrf], append ="TRUE")

              } #close for time duration

              wsrf<-wsrf+1
            } #close for inner if loop
          } # close for outer if loop

          else{ break}

        } #close for totlan loop
        rf=rf+totlon

        if(wsrf>nwsgp)
        {
          break
        }

      } # close for totlat loop

    } # close loop for simulation time peiods

  } #  close for number of projections
  return()
}

############### CORDEX Data retrieval Model ##################################################
cordex_swat_convert<- function(var1_wd,var2_gpinfo,var3a_hfl,var4a_hcdf,var5a_nvhi,
                               var6a_nfhi,var7_opfp,var8a_ofhi,var9_opstn,var_sty,var_edy){

  ####################################NEEDS TO CHANGE ########################################################
  # set-theworkingdirectory
  setwd(var1_wd)
  rcmwshedgpi<- read.table(var2_gpinfo, header=T) # rcmwshedgpi - RCM-WaterSHED-GridPoints Info
  numgp <- nrow(rcmwshedgpi)   # numgp <- NUMber of Grid Points
  nvar  <- ncol(rcmwshedgpi)   # nvar- Number of VARiables in the grid point file
  varnames <- scan(var2_gpinfo, what=" ", nlines =1) # varnames-variable names in the lat long table
  # assigning the varible names with the corrsponding values of lat-long text file

  for (j in 1:nvar)
  {
    assign(varnames[j],rcmwshedgpi[,j])
  }
  print("1")
  #reading the netcdfdata of temperature and precipitation
  library(ncdf4)
  library(chron)

  # Number of data sets for program run - Either Present or Future -1; Both Present and future-2
  datasets <- c(var3a_hfl) #Files containing the present and future files
  ndsets   <-	length(datasets)
  filefolder<-c(var4a_hcdf) #Folder names containing present and future files
  numvarinfiles     <-c(var5a_nvhi)   # Number of variables in each file list
  numfileeachvar    <-c(var6a_nfhi)   # Number of files for each variable in the file list
  print("2")
  #inputfilepath<-"D:/R/climate change/Climatechange_datadownload/Datadownload/TimeSlice-CCSM-data-140813"

  outputfilepath<-var7_opfp
  opfilefolder<-c(var8a_ofhi) #Output Folder names containing present and future files

  #giving the file name to the tempfiles and rainfall
  nasstpc <- var9_opstn  # nasttemp- Name of the Sub String for the Temperature and Precipitation files
  print("3")
  ####################################NEEDS TO CHANGE ########################################################

  # Reading the file list of temperature and precipitation names for present and future

  for(drun in 1:ndsets)   # ndsets
  {
    filevarnames <- scan(datasets[drun], what=" ", nlines =-1) # File Varaible Names- netCDF- Files of All Files variable names in the file list
    tnumfiles<-length(filevarnames)
    filepathvar<-paste(filefolder[drun],"\\", sep="")
    nfile<-numfileeachvar[drun]

    fpr<-(1:nfile)     #filename array for precipitation
    ftasmax<-(1:nfile) #filename array for maximim temperature
    ftasmin<-(1:nfile) #filename array for minimum temperature
    #Saving the filenames and path for each variable

    for(f in 1:nfile)
    {
      fpr[f]<-paste(filepathvar,filevarnames[f],sep="")
      ftasmax[f]<-paste(filepathvar,filevarnames[f+nfile],sep="")
      ftasmin[f]<-paste(filepathvar,filevarnames[f+2*nfile],sep="")
    }
    print("4")
    dir.create(file.path(outputfilepath,opfilefolder[drun]),showWarnings = FALSE)
    op_folderpath<-paste(outputfilepath,"\\",opfilefolder[drun],"/",sep="")
    op_filelist<-paste(op_folderpath,opfilefolder[drun],"_","fi_list",".txt",sep="")
    print("5")
    # Reading the files for each variable from their location
    for(f in 1:nfile)
    {
      ntasmaxk <- nc_open(ftasmax[f])
      ntasmink <- nc_open(ftasmin[f])
      npcp     <- nc_open(fpr[f])
      ntime    <- ncvar_get(ntasmaxk,"time")      #Creating the vector of timesteps
      ntimep   <- ncvar_get(npcp,"time")          #Creating the vector of timesteps
      print("6")
      # creating dates and time steps information
      stdatest<-ncatt_get(ntasmaxk,"time","units")$value
      y<-as.numeric(substring(stdatest,15,18))
      m<-as.numeric(substring(stdatest,20,21))
      d<-as.numeric(substring(stdatest,23,24))
      tsteps <- length(ntime)
      x<-tsteps+6
      print(tsteps)
      print(x)
      tdates <- seq.dates(c(var_sty),c(var_edy),by="days")
      print(tdates)

      data_stdate<-dates(tdates[1],origin=c(month=m,day=d,year=y))
      print(data_stdate)
      sty<- as.numeric(substring(as.Date(data_stdate),1,4))
      print(sty)
      print("7")
      if(y==sty)
      {
        CLYF<-0
      } else
      {
        CLYF<-sum(leap.year(y:sty))
      }

      ##tdates <- dates(ntime,origin=c(month=m,day=d+CLYF,year=y))
      ##tsteps <- length(ntime)
      print("8")
      ## Creating dates and time steps for precipitation
      stdatestp<-ncatt_get(npcp,"time","units")$value
      yp<-as.numeric(substring(stdatest,15,18))
      mp<-as.numeric(substring(stdatest,20,21))
      dp<-as.numeric(substring(stdatest,23,24))
      tsteps_p <- length(ntime)
      x<-tsteps+6
      print(tsteps)
      print(x)
      tdates_p <- seq.dates(c(var_sty),c(var_edy),by="days")
      print(tdates)

      data_stdate_p<-dates(tdates[1],origin=c(month=m,day=d,year=y))
      print(data_stdate)
      sty_p<-as.numeric(substring(as.Date(data_stdate),1,4))
      print(sty_p)
      ##data_stdate_p<-dates(ntimep[1],origin=c(month=mp,day=dp,year=yp))
      ##sty_p<-as.numeric(substring(as.Date(data_stdate),1,4))
      print("9")
      if(yp==sty_p)
      {
        CLYF<-0
      } else
      {
        CLYF<-sum(leap.year(yp:sty_p))
      }
      print("10")
      ##tdates_p <- dates(ntimep,origin=c(month=mp,day=dp+CLYF,year=yp))
      ##tsteps_p <-length(ntimep)

      if(data_stdate_p==data_stdate)
      {
        tini<-1
        tstvalue<-1
        print(tini)
      } else if(data_stdate_p > data_stdate) {
        tini <-data_stdate_p - data_stdate + 1
        tini<-as.numeric(tini)
        tstvalue<-1
        print(tini)
      } else
      {
        tini <-data_stdate - data_stdate_p + 1
        tini<-as.numeric(tini)
        print(tini)
        tstvalue<-tini
      }
      print("11")
      ########## Time steps of PCP and temperature check ##################

      if(f==1)
      {
        if(nfile!=1)
        {
          lntasmaxk<- nc_open(ftasmax[nfile])
          lntime   <- ncvar_get(lntasmaxk,"time")
          ltsteps  <- length(lntime)
          data_endate_leapless<-dates(lntime[ltsteps],origin=c(month=m,day=d,year=y))
          endy_leapless<-as.numeric(substring(as.Date(data_endate_leapless),1,4))
          TCLYF<-sum(leap.year(y:endy_leapless))
          data_endate<-dates(lntime[ltsteps],origin=c(month=m,day=d+TCLYF,year=y))
          endy<-as.numeric(substring(as.Date(data_endate),3,4))
        }
        else
        {
          data_endate<-dates(ntime[tsteps],origin=c(month=m,day=d+CLYF,year=y))
          endy<-as.numeric(substring(as.Date(data_endate),3,4))
        }
      }
      print("12")
      st_sy<- substring(as.Date(data_stdate),1,4)
      st_ey<- substring(as.Date(data_endate),3,4)


      #To store the swat inputfile for first variable
      if(f==1)
      {
        #file names to store data of temp, precipitation and grid information
        swttmpfiname<-paste(op_folderpath,nasstpc,"t",st_sy,"to",st_ey,".txt", sep="")
        swtpcpfiname<-paste(op_folderpath,nasstpc,"p",st_sy,"to",st_ey,".txt", sep="")

        # This to write the SWAT station inputfile first line
        swatipfl<-paste("ID", ",","NAME", ",","LAT",",", "LONG", ",","ELEVATION", sep ="") #SWAT INPUT file First Line
        # Creating SWAT input table variables
        SID  <- (1:numgp)    # Station ID - To give one sequence of numbers
        NAME <- (1:numgp)    # Station Name
        LAT  <- (1:numgp)    # LATitude of grid points from NETCDF
        LONG <- (1:numgp)    # LONGitude of grid points from NETCDF
        ELEV <- (1:numgp)    # Elevation of grid points from GIS      ### Elevation from GIS folder
        print("13")
        # Variables assignment from .ncdf file
        for(i in 1:numgp)
        {
          SID[i] <- i
          NAME[i]<- paste(nasstpc,st_sy,"to", st_ey, "_", xc[i],".", yc[i],sep="")
          X=xc[i]
          print(X)
          Y=yc[i]
          print(Y)
          LAT[i]  <- ncvar_get(ntasmaxk,varid='lat',start=c(Y),count=c(1))
          print(LAT[i])
          LONG[i] <- ncvar_get(ntasmaxk,varid='lon',start=c(X),count=c(1)) # To keep same format as swat
          if(LONG[i]>180)
          {
            LONG[i]<LONG[i]-360
          }

          print(LONG[i])
          ELEV[i] <- Elevation[i]       ## Elevation from text file
          print(ELEV[i])
        }
        print("14")
        # Creating the SWAT inputfile for temperatute stations
        write(swatipfl, file=swttmpfiname, append ="False")
        for(i in 1:numgp)
        {
          tmpinfo<-paste(SID[i],",",NAME[i],",",round(LAT[i],3),",",round(LONG[i],3),",", round(ELEV[i],3),sep = "")
          write(tmpinfo,file=swttmpfiname, append = "TRUE")
        }
        #creating the inputfiles for min and max temperatures for each temperature station
        tmpflis<-(1:numgp)
        datedatfnamelist<- (1:numgp)
        datedatflist<-(1:numgp) # File name for date data files
        for(i in 1: numgp)
        {
          tmpflis[i]<- paste(op_folderpath, NAME[i], "t.txt", sep="")
          datedatfnamelist[i] <-paste(NAME[i],"datedat",".txt", sep="")
          write(datedatfnamelist[i],file=op_filelist, append = "TRUE")
          datedatflist[i]<-paste(op_folderpath,datedatfnamelist[i], sep="")
        }
      } # closing for the if condition for f=1 for temperature file
      print("15")
      if(f==1)
      {
        # Variables assignment from .ncdf file
        for(i in 1:numgp)
        {
          SID[i]<- i
          NAME[i]<- paste(nasstpc,st_sy,"to", st_ey,"_", xc[i],".",yc[i],sep= "")
          X=xc[i]
          Y=yc[i]
          LAT[i] <-  ncvar_get(npcp,varid='lat',start=c(Y),count=c(1))
          LONG[i] <- ncvar_get(npcp,varid='lon',start=c(X),count=c(1)) # To keep same format as swat
          if(LONG[i]>180)
          {
            LONG[i]<LONG[i]-360
          }

          ELEV[i] <- Elevation[i]       ## Elevation from text file
        }
        # Creating the SWAT inputfile for precipitation stations
        write(swatipfl, file=swtpcpfiname, append ="False")
        for(i in 1:numgp)
        {
          pcpinfo<-paste(SID[i],",",NAME[i],",",round(LAT[i],3),",",round(LONG[i],3), ",",round(ELEV[i],3),sep = "")
          write(pcpinfo,file=swtpcpfiname, append = "TRUE")
        }
        print("16")
        #creating the inputfiles for precipitation for station
        pcpflis<-(1:numgp)

        for(i in 1: numgp)
        {
          pcpflis[i]<- paste(op_folderpath, NAME[i], "pcp.txt", sep = "")
        }

      } # close for if loop for first precipitation file

      if(f==1)
      {
        startline<-paste("DATE",",","YEAR",",","MONTH",",","DAY", ",", "MaxTemp(C)", ",", "MinTemp(C)", "," ,"Precipitation(mm)", sep="") #Modified on 031113
        firstday<- as.Date(tdates[tini])   # Corrected to add the starting date;First day of the starting file of the work
        fi1stline<- paste(substring(firstday,1,4),substring(firstday,6,7),substring(firstday,9,10),sep="")        # SWAT input format to mention the starting year
      }
      print("17")
      #Writing data to individual files
      for(i in 1:numgp)
      {
        if(f==1)
        {
          write(fi1stline, file=pcpflis[i], append ="False")
          write(fi1stline, file=tmpflis[i], append ="False")
          write(startline, file=datedatflist[i], append ="False")
        }
        LYF<-0            # leap year factor
        tstart<- tstvalue # changed to accomodate different dates of temp and pcp files
        X=xc[i]
        Y=yc[i]
        for(t in tini:tsteps) # changed to accomodate different dates of temp and pcp files
        {
          if(days(tdates[t]+LYF)==29&&months(tdates[t]+LYF)=="Feb")
          {
            #To convert temperature from Kelvin to celsius "-273.15" is used
            tasmaxc <-ncvar_get(ntasmaxk,"tasmax",start=c(X,Y,t),count=c(1,1,1))-273.15
            tasminc <-ncvar_get(ntasmink,"tasmin",start=c(X,Y,t),count=c(1,1,1))-273.15
            swttemp<-paste(round(tasmaxc,1),",",round(tasminc,1), sep="")
            #tasmaxpdc-prvious day-max temperature
            tasmaxpdc<-ncvar_get(ntasmaxk,"tasmax",start=c(X,Y,t-1),count=c(1,1,1))-273.15
            tasminpdc<-ncvar_get(ntasmink,"tasmin",start=c(X,Y,t-1),count=c(1,1,1))-273.15
            ld_tasmaxc<- (tasmaxc +tasmaxpdc)/2
            ld_tasminc<- (tasminc +tasminpdc)/2
            swttempld<-paste(round(ld_tasmaxc,1),",",round(ld_tasminc,1), sep="")
            #Rainfalldata reading
            pcpday<-ncvar_get(npcp,"pr",start=c(X,Y,t),count=c(1,1,1))
            #Previousday Precipitation
            pcpdayless<-ncvar_get(npcp,"pr",start=c(X,Y,t-1),count=c(1,1,1))

            ld_pcpday<-(pcpday+pcpdayless)/2
            ld_pcpday<-round(ld_pcpday,1)
            write(ld_pcpday,file=pcpflis[i], append="TRUE")
            pcpday<-round(pcpday,1)
            write(pcpday,file=pcpflis[i], append="TRUE")
            write(swttempld, file=tmpflis[i], append ="TRUE")
            write(swttemp,   file=tmpflis[i], append ="TRUE")
            cdate<-as.Date(tdates[t])+LYF
            #datedata<-paste(t,",",cdate,",",round(ld_tasmaxc,1),",", round(ld_tasminc,1),",", ld_pcpday, sep="")
            date_y <- as.numeric(substring(cdate,1,4))
            date_m <- as.numeric(substring(cdate,6,7))
            date_d <- as.numeric(substring(cdate,9,10))
            datedata<-paste(cdate,",",date_y,",",date_m,",",date_d,",",round(ld_tasmaxc,1),",", round(ld_tasminc,1),",", ld_pcpday, sep="")
            write(datedata, file=datedatflist[i], append ="TRUE")
            LYF=LYF+1
            cdate<-as.Date(tdates[t])+LYF
            date_y <- as.numeric(substring(cdate,1,4))
            date_m <- as.numeric(substring(cdate,6,7))
            date_d <- as.numeric(substring(cdate,9,10))
            datedata<-paste(cdate,",",date_y,",",date_m,",",date_d,",",round(tasmaxc,1),",",round(tasminc,1),",", pcpday, sep="")
            write(datedata, file=datedatflist[i], append ="TRUE")
            tstart <- (t-tini+1)
            print("18")
          }
          else
          {
            # To convert temperature from Kelvin to celsius "-273.15" is used
            tasmaxc <-ncvar_get(ntasmaxk,"tasmax",start=c(X,Y,t),count=c(1,1,1))-273.15
            tasminc <-ncvar_get(ntasmink,"tasmin",start=c(X,Y,t),count=c(1,1,1))-273.15
            swttemp<-paste(round(tasmaxc,1),",",round(tasminc,1), sep="")
            write(swttemp,   file=tmpflis[i], append ="TRUE")
            pcpday<-ncvar_get(npcp,"pr",start=c(X+1,Y+1,t),count=c(1,1,1))
            pcpday<-round(pcpday,1)
            write(pcpday,file=pcpflis[i], append="TRUE")
            cdate<-as.Date(tdates[t])+LYF
            date_y <- as.numeric(substring(cdate,1,4))
            date_m <- as.numeric(substring(cdate,6,7))
            date_d <- as.numeric(substring(cdate,9,10))
            datedata<-paste(cdate,",",date_y,",",date_m,",",date_d,",",round(tasmaxc,1),",",round(tasminc,1),",",pcpday, sep="")
            write(datedata, file=datedatflist[i], append ="TRUE")
            tstart <- (t-tini+1)  # added the correction to account late starting of rainfall file
          }


        }   # Close for time loops

      }    # Close for grid point loop

      # CLYF<-CLYF+LYF   # Adding the cumulative leaf year factor for the each period

    }  # Close for "nfile"  for number of variables for file

  } # Close for "drun" for nuber of data runs


  return()

} # Close for the function call

##Close of Codex Tool

############### Statistics Calculation Model ##################################################
stats_calc<- function(var1_wd,var2,var3,var4,var5,var6,var7,var8){
  setwd(var1_wd)
  library(chron)

  # Number of files for program run - Either Present or Future -1; Both Present and future-2
  # Files containing the present and future files
  filevarnames   <- scan(var2, what=" ", nlines =-1) # All files variable names in the file list
  tnumfiles      <- length(filevarnames)
  ipfilefolder   <- var3
  opfilefolder   <- var7

  ipfilepathvar<-paste(var3,"/",sep="")
  opfilepathvar<-paste(var4,"/",var7,"/",sep="")
  dir.create(file.path(opfilepathvar),showWarnings = FALSE)

  st_end_years_his <-c(var5,var6) # For Historic data for the purpose of means calculations
  print(st_end_years_his)
  nyhis <- st_end_years_his[2] - st_end_years_his[1]+1

  #giving the file name to the meanmonthly values and other intermediate-outputs
  memofi <- var8  # memofi- Name of the Sub String for the meanmonthly values and other intermediate-outputs
  #****************NEEDS CHANGE IN EVERY NEW MODEL RUN ******************************************************************

  #To use the month names at necessary places.
  monnamest<-c("Jan", "Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec") #Month names string
  days_month<-c(31,29,31,30,31,30,31,31,30,31,30,31)
  ydays<-sum(days_month)

  fileread<-(1:tnumfiles)
  gridnost<-(1:tnumfiles)
  for(fgp in 1:tnumfiles)
  {
    fileread[fgp] <- paste(ipfilepathvar,filevarnames[fgp], sep="")
    gridnost[fgp] <- paste(memofi,"_gp",substring(filevarnames[fgp],12,17),sep="") #10-14, 16-20; Needschange if input file name change

    tmpdata      <- read.table(fileread[fgp],sep=",",skip=1, header=F)

    tndays <- nrow(tmpdata)  # total number of days data in the file

    data_startyear <- tmpdata$V2[1]
    data_startmonth<- tmpdata$V3[1]
    data_startday  <- tmpdata$V4[1]
    data_endyear   <- tmpdata$V2[tndays]
    sy<-st_end_years_his[1]
    ey<-st_end_years_his[2]
    ny<-(ey-sy)+1        # total number of years in simulation
    tmnthny<- ny*12      # total number of months in ny years;

    # Mean monthly data of temperature and rainfall
    meanmonthfiname<-paste(opfilepathvar,gridnost[fgp],"_mmtmrf_",sy,"to",ey,".txt", sep="")
    startline<-paste("MONTH", ",", "MEAN MaxTemp", ",", "MEAN MinTemp", "," ,"Mean Precipitation", sep="")
    write(startline,file=meanmonthfiname, append="FALSE")

    for(mth in 1:12)
    {
      mean_mondata<-subset(tmpdata, tmpdata$V2>=sy & tmpdata$V2<=ey & tmpdata$V3==mth, select = c(V3,V5,V6,V7))
      memontasmax <- (sum(mean_mondata$V5))/length(mean_mondata$V5)
      memontasmin <- (sum(mean_mondata$V6))/length(mean_mondata$V6)
      mean_m_pcp  <- (sum(mean_mondata$V7))/length(mean_mondata$V7)
      monthwisedata<- paste(mth,",",round(memontasmax,1),",", round(memontasmin,1),",",round(mean_m_pcp,1), sep="")
      write(monthwisedata,file=meanmonthfiname, append="TRUE")
    }


    # Daily averge parameters over the years for temperature and rainfall
    mdailyfiname<-paste(opfilepathvar,gridnost[fgp],"_mdtmrf_",sy,"to",ey,".txt", sep="")
    startline<-paste("SNO",",","Day", ",", "MEAN MaxTemp", ",", "MEAN MinTemp", "," ,"Mean Precipitation", sep="")
    write(startline,file=mdailyfiname, append="FALSE")

    drf=0
    for(mth in 1:12)
    {
      mdays<-days_month[mth]
      for(day in 1:mdays)
      {
        dailydata<-subset(tmpdata,tmpdata$V2>=sy & tmpdata$V2<=ey  & tmpdata$V3==mth & tmpdata$V4==day, select = c(V2,V3, V4, V5,V6,V7))
        medailytasmax <-(sum(dailydata$V5))/length(dailydata$V5)
        medailytasmin <-(sum(dailydata$V6))/length(dailydata$V6)
        medailypcp    <-(sum(dailydata$V7))/length(dailydata$V7)
        daywisedata<- paste(drf+day,",",day,",", round(medailytasmax,1),",", round(medailytasmin,1),",",round(medailypcp,1),sep="")
        write(daywisedata,file=mdailyfiname, append="TRUE")
      }
      drf=drf+mdays
    }


    # Monthlydata for temperature and precipitation (aggregrate precipitation for month also calculated)
    monthfiname<-paste(opfilepathvar,gridnost[fgp],"_monthtmrf_",sy,"to",ey,".txt", sep="")
    startline<-paste("SNO",",","YEAR",",","MONTH", ",", "MEAN MaxTemp", ",", "MEAN MinTemp", "," ,"Cum Precipitation",",", "MEAN Pcp", sep="")
    write(startline,file=monthfiname, append="FALSE")

    mrf=0
    for(yea in sy:ey)
    {
      for(mth in 1:12)
      {

        monthlydata  <-  subset(tmpdata, tmpdata$V3==mth & tmpdata$V2==yea, select = c(V2,V3,V5,V6,V7))
        memontasmax  <-  (sum(monthlydata$V5))/length(monthlydata$V5)
        memontasmin  <-  (sum(monthlydata$V6))/length(monthlydata$V6)
        monpcp       <-  sum(monthlydata$V7)
        meanmonpcp   <-  (sum(monthlydata$V7))/length(monthlydata$V7)
        monthwisedata<- paste(mrf+mth, ",", yea,"," , mth, ",", round(memontasmax,1),",", round(memontasmin,1),",",round(monpcp,1),",",round(meanmonpcp,1), sep="")
        write(monthwisedata,file=monthfiname, append="TRUE")
      }
      mrf=mrf+12
    }

    # Annual data for temperature and precipitation (cumulative precipitation over the years also calculated)
    # Annual Rainfall calculation; Mean max temperature and Mean minimum temperature
    yearlydatafin<-paste(opfilepathvar,gridnost[fgp],"_annualtmrf_", sy,"to",ey,".txt", sep="")
    startline<-paste("SNO",",","YEAR", ",","MEAN MaxTemp", ",","MEAN MinTemp", "," ,"Precipitation(mm)", "," ,"CUM_PCP(mm)",sep="")
    write(startline,file=yearlydatafin, append="FALSE")

    cum_anpcp <-0
    for(yea in sy:ey)
    {
      yearlydata  <-subset(tmpdata, tmpdata$V2==yea, select = c(V2,V5,V6,V7))
      meanytasmax <-(sum(yearlydata$V5))/length(yearlydata$V5)
      meanytasmin <-(sum(yearlydata$V6))/length(yearlydata$V6)
      anualpcp    <- sum(yearlydata$V7)
      cum_anpcp <-cum_anpcp+anualpcp
      yearwisedata<- paste( yea,"," , round(meanytasmax,1),",", round(meanytasmin,1),",",round(anualpcp,1),",",round(cum_anpcp,1), sep="")
      write(yearwisedata,file=yearlydatafin, append="TRUE")
    }

  } # Close for the grid files
}

bias_swat_convert<- function(var1,var2,var3,var4,var5,var6,var7,var8,var9,var10,
                             var11,var12){

  setwd(var1)
  #************************************************************************************************

  library(chron)

  #*****************************NEEDCHANGE**********************************************************
  filevarnames_his <- scan(var2, what=" ",  nlines =-1) # All files variable names in the file list
  ##filevarnames_fu  <- scan(var4,  what=" ",  nlines =-1) # All files variable names in the file list


  # File path for the mean statistics file
  filepath_mestat_gp<- var3
  filevarnames_pcp  <- scan(var4, what=" ", nlines =-1)  # All files variable names in the file list

  # File path for the mean statistics observedstations file
  filepath_mestat_stn <- var5
  # Outputfilepath
  filepath_output<- var11
  #*****************************NEEDCHANGE*********************************************************


  ipfilepathvar_gp<-paste(filepath_mestat_gp,"/", sep="")
  ipfilepathvar_stn<-paste(filepath_mestat_stn,"/",sep="")
  opfilepathvar<-paste(var10,"/",var11,"/", sep="")
  dir.create(file.path(opfilepathvar),showWarnings = FALSE)


  ymonths<-12   # Total number of months in year - Two declare for two dimvaraibile for delta changetot<-3    # SWAT variables like max and min temperature, precipitation
  totgpoints<-length(filevarnames_his)
  arsize<-ymonths*totgpoints
  biascorrpcp  <-  array(1:arsize, dim=c(ymonths,totgpoints)) # Bias-correc for precipitation
  biascorrmxtp <-  array(1:arsize, dim=c(ymonths,totgpoints)) # Bias-correc for max temperature
  biascorrmitp <-  array(1:arsize, dim=c(ymonths,totgpoints)) # Bias-correc for min temperature


  #To use the month names at necessary places.
  monnamest<-c("Jan", "Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec") #Month names string
  days_month<-c(31,29,31,30,31,30,31,31,30,31,30,31)
  ydays<-sum(days_month)


  # Deltachange and bis correction file
  ##deltchange  <-  "deltachangeval"
  biascorrec  <-  "biascorreval"

  fileread_his<-(1:totgpoints)
  fileread_fu<-(1:totgpoints)
  fileread_pcp<-(1:totgpoints)
  ##fileread_tmp<-(1:totgpoints)

  for(fgp in 1:totgpoints)
  {
    fileread_his[fgp] <- paste(ipfilepathvar_gp,filevarnames_his[fgp], sep="")
    fileread_pcp[fgp] <- paste(ipfilepathvar_stn,filevarnames_pcp[fgp], sep="")

    gpmeanmthdata_his <- read.table(fileread_his[fgp], sep=",",skip=1, header=F)

    meanobpcp <-read.table(fileread_pcp[fgp],sep=",",skip=1, header=F)

    #Calculation of Biascorrections
    biascorrfi <-paste(opfilepathvar,biascorrec,"_",substring(filevarnames_his[fgp],1,14), ".txt", sep="")
    startline<-paste("MONTH", ",", "Biascor_MaxTemp", ",", "Biascor_MinTemp", "," ,"Biascor_Precipitation", sep="")
    write(startline,file=biascorrfi, append="FALSE")

    for(mth in 1:12)
    {
      biascorrpcp[mth,fgp]  <- meanobpcp$V4[mth]/gpmeanmthdata_his$V4[mth]
      biascorrmxtp[mth,fgp] <- meanobpcp$V2[mth] - gpmeanmthdata_his$V2[mth]
      biascorrmitp[mth,fgp] <- meanobpcp$V3[mth] - gpmeanmthdata_his$V3[mth]
      biacorrvlaue<- paste(mth,",",round(biascorrmxtp[mth,fgp],3),",", round(biascorrmitp[mth,fgp],3),",",round(biascorrpcp[mth,fgp],3), sep="")
      write(biacorrvlaue,file=biascorrfi , append="TRUE")
    }

  }

  ######################## BIAS CORRECTION ####################################################################
  # Preparation of biascorrected grid point files in SWAT format and in General format
  # **************************************************************************************** #

  # Number of files for program run - Either Present or Future -1; Both Present and future-2
  # Files containing the present and future files

  #**********************************NEED CHANGE**************************************************************************
  filevarnames   <- scan(var6, what=" ", nlines =-1) # All files variable names in the file list
  tnumfiles      <- length(filevarnames)
  ipfilefolder   <- var7
  opfilefolder   <- var11

  ipfilepathvar<-paste(ipfilefolder,"/", sep="")
  opfilepathvar<-paste(var10,"/",var11,"/", sep="")

  st_end_years_his <-c(var8, var9) # For Historic data for the purpose of preparingswatinputs
  nyhis <- st_end_years_his[2] - st_end_years_his[1]+1

  #giving the file name to the meanmonthly values and other intermediate-outputs
  memofi <- var12  # memofi- Name of the Sub String for the meanmonthly values and other intermediate-outputs

  #**********************************NEED CHANGE****************************************************************************


  #Number of grid points
  totgridpoints<-ncol(biascorrmxtp)

  #To use the month names at necessary places.
  monnamest<-c("Jan", "Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec") #Month names string
  days_month<-c(31,28,31,30,31,30,31,31,30,31,30,31)
  ydays<-sum(days_month)

  fileread <-(1:tnumfiles)
  gridnost <-(1:tnumfiles)
  for(fgp in 1:tnumfiles)
  {
    if(fgp<=totgridpoints)
    {
      gp <-fgp
      print(gp)
    }
    else
    {
      gp<-fgp-totgridpoints
      print(gp)
    }

    fileread[fgp] <- paste(ipfilepathvar,filevarnames[fgp], sep="")
    gridnost[fgp] <- paste(memofi,"_gp",substring(filevarnames[fgp],13,18),sep="")

    tmpdata      <- read.table(fileread[fgp],sep=",",skip=1, header=F)
    tndays <- nrow(tmpdata)  # total number of days data in the file
    ttimes <-(1:tndays)      # to prepare the time step ddays

    data_startyear <- tmpdata$V2[1]
    data_startmonth<- tmpdata$V3[1]
    data_startday  <- tmpdata$V4[1]
    data_endyear   <- tmpdata$V2[tndays]

    sy<-st_end_years_his[1]
    ey<-st_end_years_his[2]

    ny<-(ey-sy)+1        # total number of years in simulation
    tmnthny<- ny*12      # total number of months in ny years;

    tmpdata_sytey <- subset(tmpdata, tmpdata$V2>=sy & tmpdata$V2<=ey, select=c(V1:V7))


    # Temperature and precipitation bias corrected and swat model format
    biacorfiname<-paste(opfilepathvar,gridnost[fgp],"_biascorr_",sy,"to",ey,".txt", sep="")
    startline<-paste("SNO",",","YEAR",",","MONTH", ",", "DAY",",", "Biacorr_MaxTemp", ",", "Biacorr_MinTemp", "," ,"Biacorr_Precipitation",sep="")
    write(startline,file=biacorfiname, append="FALSE")

    pcpflis <- paste(opfilepathvar,gridnost[fgp],"_swpcpbiascr_",sy,"to",ey,".txt", sep="")
    tmpflis <- paste(opfilepathvar,gridnost[fgp],"_swtmpbiascr_",sy,"to",ey,".txt", sep="")

    drf=0
    for(yea in sy:ey)
    {
      if(leap.year(yea)=="TRUE")
      {
        days_month[2]=29
      }
      else
      {
        days_month[2]=28
      }

      for(mth in 1:12)
      {

        mdays<-days_month[mth]
        for(day in 1:mdays)
        {
          if((drf+day)==1)
          {
            drfidate<-subset(tmpdata_sytey,tmpdata_sytey$V2==sy & tmpdata_sytey$V3==1& tmpdata_sytey$V4==1, select = c(V2:V4))
            firstline<- paste(drfidate$V2[1],"0",drfidate$V3[1],"0",drfidate$V4[1],sep="")        # SWAT input format to mention the starting year
            write(firstline, file=pcpflis, append ="False")
            write(firstline, file=tmpflis, append ="False")
          }
          biacorrtasmax <-  tmpdata_sytey$V5[drf+day]+biascorrmxtp[mth,gp]
          biacorrtasmin <-  tmpdata_sytey$V6[drf+day]+biascorrmitp[mth,gp]
          biacorrpcp    <-  tmpdata_sytey$V7[drf+day]*biascorrpcp[mth, gp]
          biascorrdata  <- paste(drf+day, ",", yea,"," , mth, ",", day,",", round(biacorrtasmax,1),",", round(biacorrtasmin,1),",",round(biacorrpcp,1), sep="")
          write(biascorrdata,file=biacorfiname, append="TRUE")
          swttemp<-paste(round(biacorrtasmax,1),",",round(biacorrtasmin,1), sep="")
          write(swttemp,   file=tmpflis, append ="TRUE")
          pcpday<-round(biacorrpcp,1)
          write(pcpday,file=pcpflis, append="TRUE")

        }
        drf=drf+mdays
      } #close for months


    }  # close for years
  }
}


library(RGtk2)
library(memoise)
library(gWidgets2)
library(gWidgets2RGtk2)

#****************************NEED CHANGE*********************************************************
setwd("C:/Users/Administrator/Documents/R/win-library/3.3")
#************************************************************************************************

##############Creation of Main Window of GUI #######################
window_clsw <- gtkWindow("toplevel", show = FALSE)  # clsw=Climate Model SWAT model
##window_clsw$setDefaultSize(600,500)
window_clsw$setTitle("CLIM-R")
frame_clsw = gtkFrameNew()
vbox_clsw = gtkVBoxNew(FALSE, 8)
vbox_clsw$setBorderWidth(24)
frame_cmds=gtkFrameNew("TOOL SELECTION")
gtkFrameSetLabelAlign(frame_cmds,0.5,0.5)
vbox_clsw$packStart(frame_cmds,expand = FALSE , fill = FALSE,10)
vbox_cmds= gtkVBoxNew(FALSE, 8)
hbox1 <-gtkHBoxNew(FALSE,8)
hbox2 <-gtkHBoxNew(FALSE,8)
#box2 <-gtkHBoxNew(FALSE,5)
button_a <- gtkButton(" DATA RETRIEVAL TOOL ")
button_b <- gtkButton(" STATISTICS CALCULATION TOOL ")
button_c <- gtkButton(" BIAS CORRECTION TOOL ")
button_d <- gtkButton(" DELTA CORRECTION TOOL ")
button_e <- gtkButton(" VISUALIZATION TOOL ")
hbox1$packStart(button_a, expand = TRUE , fill = FALSE,10)
hbox1$packStart(button_b, expand = TRUE , fill = FALSE,10)
hbox1$packStart(button_c, expand = TRUE , fill = FALSE,10)
hbox2$packStart(button_d, expand = TRUE , fill = FALSE,10)
hbox2$packStart(button_e, expand = TRUE , fill = FALSE,10)
vbox_cmds$packStart(hbox1,expand = TRUE , fill = FALSE,10)
vbox_cmds$packStart(hbox2,expand = TRUE , fill = FALSE,10)
frame_cmds$add(vbox_cmds)
frame_insti_logo = gtkFrameNew()
vbox_clsw$packStart(frame_insti_logo)
vbox_insti_logo <- gtkVBoxNew()
hbox_insti_logo <-gtkHBoxNew()
image_tamu_logo<-gtkImageNewFromFile(filename="D:\\R\\summer\\R-GUI\\agrilife.png", show = TRUE)
image_nitw_logo<-gtkImageNewFromFile(filename="D:\\R\\summer\\R-GUI\\nitw.png", show = TRUE)
hbox_insti_logo$packStart(image_nitw_logo, expand = TRUE , fill = FALSE, 50)
hbox_insti_logo$packStart(image_tamu_logo, expand = TRUE , fill = FALSE, 50)

vbox_insti_logo$packStart(hbox_insti_logo,expand = FALSE , fill = FALSE )
frame_insti_logo$add(vbox_insti_logo)

#Adding the text information of the tool development
frame_tdi= gtkFrameNew("TOOL DEVELOPMENT INFORMATION")
gtkFrameSetLabelAlign(frame_tdi,0.5,0.5)
vbox_clsw$packStart(frame_tdi,expand = FALSE , fill = FALSE,10)
vbox_tdi = gtkVBoxNew(FALSE, 8)
hbox_spt  <-gtkHBoxNew(FALSE,8)
hbox_spt['spacing'] <-20
spons_text<-"This tool was initiated as part of the post doctoral research work of Dr.K.Venkata Reddy under Indo-US 21'st Century Initiative
Raman fellowship award by UGC,GOI in the year 2013-14 and subsequent work was carried out at NIT Warangal, India."
sponsor_label<-gtkLabel(spons_text)
sponsor_label$setJustify("center")
hbox_spt$packStart(sponsor_label)
hbox_conp  <-gtkHBoxNew(FALSE,8)
hbox_conp['spacing'] <-20
contact_p<-"Contact Details:
Dr. K.Venkata Reddy,Asst.Professor, NIT Warangal, India, Email: kvreddy@nitw.ac.in
J. Sri Lakshmi Sesha Vani, Post Graduate Student, NIT Warangal, India, Email: vani.j88@gmail.com
Dr. Prasad Daggupati,Postdoctral Research Scientist,Texas A&M University,USA, Email:pdaggupati@tamu.edu
Prof. Raghavan Srinivsan,Director&Professor,SSL,Texas A&M University,USA,, Email:r-srinivasan@tamu.edu"
contact_label<-gtkLabel(contact_p)
contact_label$setJustify("left")
hbox_conp$packStart(contact_label)
vbox_tdi$packStart(hbox_spt)
vbox_tdi$packStart(hbox_conp)
frame_tdi$add(vbox_tdi)

frame_clsw$add(vbox_clsw)
#frame_clsw$add(box1)
#frame_clsw2$add(box1)
#window_clsw$add(box1)
window_clsw$add(frame_clsw)
window_clsw$show()

dataretrieval<-function(){
  window_data <- gtkWindow("toplevel", show = FALSE)
  window_data$set(title="DATA RETRIEVAL TOOL")
  frame_data = gtkFrameNew()
  vbox_data = gtkVBoxNew(FALSE, 8)
  vbox_data$setBorderWidth(24)
  frame_data_c=gtkFrameNew("CLIMATE MODEL DATABASE SELECTION")
  gtkFrameSetLabelAlign(frame_data_c,0.5,0.5)
  vbox_data$packStart(frame_data_c,expand = FALSE , fill = FALSE,10)
  vbox_data_c= gtkVBoxNew(FALSE, 8)
  hbox1 <-gtkHBoxNew(FALSE,8)
  #box2 <-gtkHBoxNew(FALSE,5)
  button_a_d <- gtkButton("        NARCCAP -USA
                          (www.narccap.ucar.edu)")
  button_b_d <- gtkButton("                                       CMIP5 -USA
                          (http://gdo-dcp.ucllnl.org/downscaled_cmip_projections)")
  button_c_d <- gtkButton("           CORDEX -SOUTH ASIA
                          (http://cccr.tropmet.res.in/cordex) ")
  hbox1$packStart(button_a_d, expand = FALSE , fill = FALSE,10)
  hbox1$packStart(button_b_d, expand = FALSE , fill = FALSE,10)
  hbox1$packStart(button_c_d, expand = FALSE , fill = FALSE,10)
  vbox_data_c$packStart(hbox1,expand = FALSE , fill = FALSE,10)
  frame_data$add(vbox_data)
  frame_data_c$add(vbox_data_c)
  window_data$add(frame_data)
  window_data$add(frame_data)
  window_data$show()
  gSignalConnect(button_a_d,"clicked", function(button_a_d){narccapwinfun()})
  gSignalConnect(button_b_d,"clicked", function(button_b_d){CMIP5winfun()})
  gSignalConnect(button_c_d,"clicked", function(button_c_d){cordex()})
}
gSignalConnect(button_a,"clicked", function(button_a){dataretrieval()})

statistics <- function(){
  stat_window<-gtkWindow(show=FALSE)
  stat_window$set(title="STATISTICS CALCULATION TOOL")
  frame_stat =gtkFrameNew()
  vbox_n = gtkVBoxNew(FALSE, 8)
  vbox_n$setBorderWidth(24)

  ### Horizointal box and its contents to set the working Directory########
  hbox_swd <-gtkHBoxNew(FALSE,8)
  hbox_swd['spacing'] <-90
  hbox_swd$packStart(gtkLabel("   Select the Working Directory:"),FALSE)
  file_ch_swd <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  gSignalConnect(file_ch_swd, "selection-changed",
                 function(file_ch_swd) {
                   wdname <<- file_ch_swd$getFilename()       # "<<-" making wdname global variable
                   print(paste("selected", wdname))
                 })
  hbox_swd$packStart(file_ch_swd)
  vbox_n$packStart(hbox_swd,expand = FALSE , fill = FALSE,10)

  ####### H-Box close for set the working directory##############

  ##File list selection##
  ##### To Keep the frame for Climate Date sets Information
  frame_i = gtkFrameNew("INPUT INFORAMTION")
  vbox_n$packStart(frame_i,expand = TRUE , fill = TRUE,10)
  vbox_ch<-gtkVBoxNew(TRUE,8)
  ## Horizointal box and its contents to select the watershed climate grid points txt file###
  hbox_gpf_n <-gtkHBoxNew(FALSE,8)
  hbox_gpf_n['spacing'] <-95
  hbox_gpf_n$packStart(gtkLabel("   Input File List Text File(*.txt):"),FALSE)
  file_ch_gpf <- gtkFileChooserButton("Select a file...",
                                      "select-file")
  file_ch_gpf$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_gpf, "selection-changed",
                 function(file_ch_gpf) {
                   gpfile <<- file_ch_gpf$getFilename()     # "<<-" making gpfile global variable
                   print(paste("selected", gpfile))
                 })
  hbox_gpf_n$packStart(file_ch_gpf)
  vbox_ch$packStart(hbox_gpf_n,expand = TRUE , fill = TRUE,10)
  ################# code completes -H-Box climate grid points txt file ########################################


  #*****************Code for adding the folder path for climate files ****************************************#
  hbox_cdff_n <-gtkHBoxNew(FALSE,8)
  hbox_cdff_n['spacing'] <-90
  hbox_cdff_n$packStart(gtkLabel("   Climate Date Files Folder:       "),FALSE)
  file_ch_cdffh <- gtkFileChooserButton("Select a folder...",
                                        "select-folder")
  file_ch_cdffh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_cdffh, "selection-changed",
                 function(file_ch_cdffh) {
                   his_dtfo <<- file_ch_cdffh$getFilename()   # "<<-" making his_dtfo global variable
                   print(paste("selected", his_dtfo))
                 })
  hbox_cdff_n$packStart(file_ch_cdffh)
  vbox_ch$packStart(hbox_cdff_n,expand = TRUE , fill = TRUE,10)
  ##code for adding folder is complete##

  ##Code for start and end years##
  hbox_styr<-gtkHBoxNew(FALSE,8)
  hbox_styr['spacing']<-108
  hbox_styr$packStart(gtkLabel("   Enter Starting Year:            "),FALSE)
  entry1<-gtkEntry()
  hbox_styr$packStart(entry1)
  vbox_ch$packStart(hbox_styr,expand=FALSE,fill=FALSE,10)

  hbox_edyr<-gtkHBoxNew(FALSE,8)
  hbox_edyr['spacing']<-114
  hbox_edyr$packStart(gtkLabel("   Enter Ending Year:           "),FALSE)
  entry2<-gtkEntry()
  hbox_edyr$packStart(entry2)
  vbox_ch$packStart(hbox_edyr,expand=FALSE,fill=FALSE,10)
  frame_i$add(vbox_ch)


  ##complete##

  ##### To Keep the frame for  Output files Information
  frame_opfi = gtkFrameNew("OUTPUT FILES INFORAMTION")
  vbox_n$packStart(frame_opfi,expand = FALSE , fill = FALSE,10)
  vbox_op<-gtkVBoxNew(FALSE,8)
  ## Code for outputfile folder location
  hbox_opfl_n <-gtkHBoxNew(FALSE,8)
  hbox_opfl_n['spacing'] <-118
  hbox_opfl_n$packStart(gtkLabel("   Ouput Folder Location:"),FALSE)
  file_ch_opfl <- gtkFileChooserButton("Select a folder...",
                                       "select-folder")
  file_ch_opfl$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_opfl, "selection-changed",
                 function(file_ch_opfl) {
                   op_loc <<- file_ch_opfl$getFilename()     # "<<-" making op_loc global variable
                   print(paste("selected", op_loc))
                 })
  hbox_opfl_n$packStart(file_ch_opfl)
  vbox_op$packStart(hbox_opfl_n,expand = FALSE , fill = FALSE,10)
  ## Code for outputfile folder location

  ##### Code for selection of output folder names for historic amd future ############################################
  hbox1_opfn <-gtkHBoxNew(FALSE,8)
  hbox1_opfn['spacing'] <-85
  hbox1_opfn$packStart(gtkLabel("   Output Folder Name:              "),FALSE)
  entry5 <- gtkEntry()
  hbox1_opfn$packStart(entry5)
  gtkEditableInsertText(entry5,"Statistcs", position = 0)

  vbox_op$packStart(hbox1_opfn,expand = FALSE , fill = FALSE,10)
  ##### Number of climate variables information ############################################



  ## Code for ouput file starting name  selection ##
  hbox1_osn <-gtkHBoxNew(FALSE,8)
  hbox1_osn['spacing'] <-103
  hbox1_osn$packStart(gtkLabel("   Outputfile Starting String:"),FALSE)
  entry0 <- gtkEntry()
  hbox1_osn$packStart(entry0)
  gtkEditableInsertText(entry0,"WAR", position = 0)
  vbox_op$packStart(hbox1_osn,expand = FALSE , fill = FALSE,10)
  frame_opfi$add(vbox_op)
  ## Code for ouput file starting name  selection ##

  ### Code for selection of all input signals and writing them to variables ##############
  hbox2_n <-gtkHBoxNew(TRUE,8)
  button_run_n <- gtkButton("RUN")
  hbox2_n$packStart(button_run_n, expand = FALSE , fill = FALSE,10)
  vbox_n$packStart(hbox2_n,expand = FALSE , fill = FALSE,10)
  frame_stat$add(vbox_n)
  stat_window$add(frame_stat)
  gSignalConnect(button_run_n,"clicked", function(button){  st_yr<-as.numeric(entry1$getText())
  ed_yr<-as.numeric(entry2$getText())
  opfo_his<-entry5$getText()
  ##opfo_fu<-entry6$getText()

  nasstp <-entry0$getText()
  print(nasstp)
  print(wdname)
  print(gpfile)

  print(his_dtfo)

  print(op_loc)
  print(opfo_his)
  print(st_yr)
  print(ed_yr)
  stats_calc(wdname,gpfile,his_dtfo,op_loc,st_yr,ed_yr,opfo_his,nasstp)
  })
  stat_window$show()
}
gSignalConnect(button_b,"clicked", function(button_b){statistics()})

bias_correction<- function(){
  bias_window<-gtkWindow(show=FALSE)
  bias_window$set(title="BIAS CORRECTION TOOL")
  frame_bias =gtkFrameNew()
  vbox_b = gtkVBoxNew(FALSE, 8)
  vbox_b$setBorderWidth(24)

  ### Horizointal box and its contents to set the working Directory########
  hbox_swd_b <-gtkHBoxNew(FALSE,8)
  hbox_swd_b['spacing'] <-90
  hbox_swd_b$packStart(gtkLabel("   Select the Working Directory:"),FALSE)
  file_ch_swd <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  gSignalConnect(file_ch_swd, "selection-changed",
                 function(file_ch_swd) {
                   wdname <<- file_ch_swd$getFilename()       # "<<-" making wdname global variable
                   print(paste("selected", wdname))
                 })
  hbox_swd_b$packStart(file_ch_swd)
  vbox_b$packStart(hbox_swd_b,expand = FALSE , fill = FALSE,10)

  ####### H-Box close for set the working directory##############
  ##### To Keep the frame for Climate Date sets Information
  frame_cdi = gtkFrameNew("    CLIMATE DATA SETS INFORAMTION")
  vbox_b$packStart(frame_cdi,expand = TRUE , fill = TRUE,10)
  vbox_ch<-gtkVBoxNew(TRUE,8)
  ## Horizointal box and its contents to select the watershed climate grid points txt file###
  hbox_msh_b <-gtkHBoxNew(FALSE,8)
  hbox_msh_b['spacing'] <-2
  hbox_msh_b$packStart(gtkLabel(" Historic Monthly Statistics filelist (*.txt):      "),FALSE)
  file_ch_msh <- gtkFileChooserButton("Select a file...",
                                      "select-file")
  file_ch_msh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_msh, "selection-changed",
                 function(file_ch_msh) {
                   gpfile <<- file_ch_msh$getFilename()     # "<<-" making gpfile global variable
                   print(paste("selected", gpfile))
                 })
  hbox_msh_b$packStart(file_ch_msh, expand=TRUE, fill= TRUE, 5)
  hbox_msh_b$packStart(gtkLabel("  Folder path:"),FALSE)
  file_ch_msh <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  file_ch_msh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_msh, "selection-changed",
                 function(file_ch_msh) {
                   fpath1 <<- file_ch_msh$getFilename()     # "<<-" making fpath1 global variable
                   print(paste("selected", fpath1))
                 })
  hbox_msh_b$packEnd(file_ch_msh)
  vbox_ch$packStart(hbox_msh_b,expand = FALSE, fill = FALSE,10)


  hbox_obs_b <-gtkHBoxNew(FALSE,8)
  hbox_obs_b['spacing'] <-10
  hbox_obs_b$packStart(gtkLabel(" Observed Monthly Statistics filelist (*.txt): "),FALSE)
  file_ch_obs <- gtkFileChooserButton("Select a file...",
                                      "select-file")
  file_ch_obs$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_obs, "selection-changed",
                 function(file_ch_obs) {
                   gpfile_obs <<- file_ch_obs$getFilename()     # "<<-" making gpfile_obs global variable
                   print(paste("selected", gpfile_obs))
                 })
  hbox_obs_b$packStart(file_ch_obs)
  hbox_obs_b$packStart(gtkLabel("Folder path:"),FALSE)
  file_ch_obs <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  file_ch_obs$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_obs, "selection-changed",
                 function(file_ch_obs) {
                   fpath3 <<- file_ch_obs$getFilename()     # "<<-" making fpath3 global variable
                   print(paste("selected", fpath3))
                 })
  hbox_obs_b$packStart(file_ch_obs)
  vbox_ch$packStart(hbox_obs_b,expand = TRUE , fill = TRUE,10)




  ##*****************Code for adding the files list text file  for present and future **********************#
  hbox_fltf_b <-gtkHBoxNew(FALSE,8)
  hbox_fltf_b['spacing'] <-10
  hbox_fltf_b$packStart(gtkLabel(" Climate Data File List Text File(*.txt):          "),FALSE)

  file_ch_fltfh <- gtkFileChooserButton("Select a file...",
                                        "select-file")
  file_ch_fltfh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_fltfh, "selection-changed",
                 function(file_ch_fltfh) {
                   his_fili <<- file_ch_fltfh$getFilename()     # "<<-" making his_fili global variable
                   print(paste("selected", his_fili))
                 })
  hbox_fltf_b$packStart(file_ch_fltfh)
  hbox_fltf_b$packStart(gtkLabel("Folder path:"),FALSE)
  file_ch_fltff <- gtkFileChooserButton("Select a folder...",
                                        "select-folder")
  file_ch_fltff$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_fltff, "selection-changed",
                 function(file_ch_fltff) {
                   fu_fili <<- file_ch_fltff$getFilename()     #  "<<-" making fu_fili global variable
                   print(paste("selected", fu_fili))
                 })
  hbox_fltf_b$packStart(file_ch_fltff)
  vbox_ch$packStart(hbox_fltf_b,expand = FALSE , fill = FALSE,10)
  frame_cdi$add(vbox_ch)

  ##### Starting and ending years for historic data ############################################
  hbox1_ncv <-gtkHBoxNew(FALSE,8)
  hbox1_ncv['spacing'] <-35
  hbox1_ncv$packStart(gtkLabel("Starting year of Climate Data:             "),FALSE)
  entry1 <- gtkEntry()
  hbox1_ncv$packStart(entry1)
  gtkEditableInsertText(entry1,"1970", position = 0)
  hbox1_ncv$packStart(gtkLabel("                Ending year of Climate Data:              "),FALSE)
  entry2 <- gtkEntry()
  hbox1_ncv$packStart(entry2)
  gtkEditableInsertText(entry2,"2005", position = 0)
  vbox_ch$packStart(hbox1_ncv,expand = FALSE , fill = FALSE)
  ##### Starting and ending years for historic data  ############################################

  ##### To Keep the frame for  Output files Information
  frame_opfi = gtkFrameNew("OUTPUT FILES INFORAMTION")
  vbox_b$packStart(frame_opfi,expand = FALSE , fill = FALSE,10)
  vbox_op<-gtkVBoxNew(FALSE,8)
  ## Code for outputfile folder location
  hbox_opfl_n <-gtkHBoxNew(FALSE,8)
  hbox_opfl_n['spacing'] <-118
  hbox_opfl_n$packStart(gtkLabel("   Ouput Folder Location:"),FALSE)
  file_ch_opfl <- gtkFileChooserButton("Select a folder...",
                                       "select-folder")
  file_ch_opfl$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_opfl, "selection-changed",
                 function(file_ch_opfl) {
                   op_loc <<- file_ch_opfl$getFilename()     # "<<-" making op_loc global variable
                   print(paste("selected", op_loc))
                 })
  hbox_opfl_n$packStart(file_ch_opfl)
  vbox_op$packStart(hbox_opfl_n,expand = FALSE , fill = FALSE,10)
  ## Code for outputfile folder location

  ##### Code for selection of output folder names for historic amd future ############################################
  hbox1_opfn <-gtkHBoxNew(FALSE,8)
  hbox1_opfn['spacing'] <-83
  hbox1_opfn$packStart(gtkLabel("   Output Folder Name:              "),FALSE)
  entry5 <- gtkEntry()
  hbox1_opfn$packStart(entry5)
  gtkEditableInsertText(entry5,"Bais_Corrected_Data", position = 0)
  vbox_op$packStart(hbox1_opfn,expand = FALSE , fill = FALSE,10)
  ##### Number of climate variables information ############################################

  ## Code for ouput file starting name  selection ##
  hbox1_osn <-gtkHBoxNew(FALSE,8)
  hbox1_osn['spacing'] <-103
  hbox1_osn$packStart(gtkLabel("   Outputfile Starting String:"),FALSE)
  entry0 <- gtkEntry()
  hbox1_osn$packStart(entry0)
  gtkEditableInsertText(entry0,"WS", position = 0)
  vbox_op$packStart(hbox1_osn,expand = FALSE , fill = FALSE,10)
  frame_opfi$add(vbox_op)
  ## Code for ouput file starting name  selection ##

  ### Code for selection of all input signals and writing them to variables ##############
  hbox2_n <-gtkHBoxNew(TRUE,8)
  button_run_n <- gtkButton("RUN")
  hbox2_n$packStart(button_run_n, expand = FALSE , fill = FALSE,10)
  vbox_b$packStart(hbox2_n,expand = FALSE , fill = FALSE,10)
  frame_bias$add(vbox_b)
  bias_window$add(frame_bias)
  gSignalConnect(button_run_n,"clicked", function(button){  styrhis <- as.numeric(entry1$getText())
  enyrhis  <- as.numeric(entry2$getText())
  opfo_his<-entry5$getText()
  nasstp <-entry0$getText()
  print(styrhis)
  print(enyrhis)
  print(nasstp)
  print(wdname)
  print(gpfile)
  print(fpath1)
  print(gpfile_obs)
  print(fpath3)
  print(his_fili)
  print(fu_fili)
  print(op_loc)
  clim_swat_convert(wdname,gpfile,fpath1,gpfile_obs,fpath3,his_fili,fu_fili,styrhis,enyrhis,op_loc,opfo_his,nasstp)
  })
  bias_window$show()
}
gSignalConnect(button_c,"clicked", function(button_c){bias_correction()})

delta_correction<- function(){
  bias_window<-gtkWindow(show=FALSE)
  bias_window$set(title="DELTA CORRECTION TOOL")
  frame_bias =gtkFrameNew()
  vbox_b = gtkVBoxNew(FALSE, 8)
  vbox_b$setBorderWidth(24)

  ### Horizointal box and its contents to set the \working Directory########
  hbox_swd_b <-gtkHBoxNew(FALSE,8)
  hbox_swd_b['spacing'] <-90
  hbox_swd_b$packStart(gtkLabel("   Select the Working Directory:"),FALSE)
  file_ch_swd <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  gSignalConnect(file_ch_swd, "selection-changed",
                 function(file_ch_swd) {
                   wdname <<- file_ch_swd$getFilename()       # "<<-" making wdname global variable
                   print(paste("selected", wdname))
                 })
  hbox_swd_b$packStart(file_ch_swd)
  vbox_b$packStart(hbox_swd_b,expand = FALSE , fill = FALSE,10)

  ####### H-Box close for set the working directory##############
  ##### To Keep the frame for Climate Date sets Information
  frame_cdi = gtkFrameNew("    CLIMATE DATA SETS INFORAMTION")
  vbox_b$packStart(frame_cdi,expand = TRUE , fill = TRUE,10)
  vbox_ch<-gtkVBoxNew(TRUE,8)
  ## Horizointal box and its contents to select the watershed climate grid points txt file###
  hbox_msh_b <-gtkHBoxNew(FALSE,8)
  hbox_msh_b['spacing'] <-2
  hbox_msh_b$packStart(gtkLabel(" Monthly Statistics historic filelist (*.txt):       "),FALSE)
  file_ch_msh <- gtkFileChooserButton("Select a file...",
                                      "select-file")
  file_ch_msh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_msh, "selection-changed",
                 function(file_ch_msh) {
                   gpfile <<- file_ch_msh$getFilename()     # "<<-" making gpfile global variable
                   print(paste("selected", gpfile))
                 })
  hbox_msh_b$packStart(file_ch_msh, expand=TRUE, fill= TRUE, 5)
  hbox_msh_b$packStart(gtkLabel("  Folder path:"),FALSE)
  file_ch_msh <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  file_ch_msh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_msh, "selection-changed",
                 function(file_ch_msh) {
                   fpath1 <<- file_ch_msh$getFilename()     # "<<-" making fpath1 global variable
                   print(paste("selected", fpath1))
                 })
  hbox_msh_b$packEnd(file_ch_msh)
  vbox_ch$packStart(hbox_msh_b,expand = FALSE, fill = FALSE,10)

  ## Horizointal box and its contents to select the watershed climate grid points txt file###
  hbox_msf_b <-gtkHBoxNew(FALSE,8)
  hbox_msf_b['spacing'] <-12
  hbox_msf_b$packStart(gtkLabel(" Monthly Statistics future filelist (*.txt):       "),FALSE)
  file_ch_msf <- gtkFileChooserButton("Select a file...",
                                      "select-file")
  file_ch_msf$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_msf, "selection-changed",
                 function(file_ch_msf) {
                   gpfile_fu <<- file_ch_msf$getFilename()     # "<<-" making gpfile_fu global variable
                   print(paste("selected", gpfile_fu))
                 })
  hbox_msf_b$packStart(file_ch_msf)
  hbox_msf_b$packStart(gtkLabel("Folder path:"),FALSE)
  file_ch_msf <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  file_ch_msf$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_msf, "selection-changed",
                 function(file_ch_msf) {
                   fpath2 <<- file_ch_msf$getFilename()     # "<<-" making fpath2 global variable
                   print(paste("selected", fpath2))
                 })
  hbox_msf_b$packStart(file_ch_msf)
  vbox_ch$packStart(hbox_msf_b,expand = TRUE , fill = TRUE,10)

  hbox_obs_b <-gtkHBoxNew(FALSE,8)
  hbox_obs_b['spacing'] <-10
  hbox_obs_b$packStart(gtkLabel(" Monthly Statistics Observed filelist (*.txt):  "),FALSE)
  file_ch_obs <- gtkFileChooserButton("Select a file...",
                                      "select-file")
  file_ch_obs$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_obs, "selection-changed",
                 function(file_ch_obs) {
                   gpfile_obs <<- file_ch_obs$getFilename()     # "<<-" making gpfile_obs global variable
                   print(paste("selected", gpfile_obs))
                 })
  hbox_obs_b$packStart(file_ch_obs)
  hbox_obs_b$packStart(gtkLabel("Folder path:"),FALSE)
  file_ch_obs <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  file_ch_obs$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_obs, "selection-changed",
                 function(file_ch_obs) {
                   fpath3 <<- file_ch_obs$getFilename()     # "<<-" making fpath3 global variable
                   print(paste("selected", fpath3))
                 })
  hbox_obs_b$packStart(file_ch_obs)
  vbox_ch$packStart(hbox_obs_b,expand = TRUE , fill = TRUE,10)




  ##*****************Code for adding the files list text file  for present and future **********************#
  hbox_fltf_b <-gtkHBoxNew(FALSE,8)
  hbox_fltf_b['spacing'] <-10
  hbox_fltf_b$packStart(gtkLabel(" Climate Data File List Text File(*.txt):
                                 (Uncorrected/ Bias Corrected/ Observed)   "),FALSE)

  file_ch_fltfh <- gtkFileChooserButton("Select a file...",
                                        "select-file")
  file_ch_fltfh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_fltfh, "selection-changed",
                 function(file_ch_fltfh) {
                   his_fili <<- file_ch_fltfh$getFilename()     # "<<-" making his_fili global variable
                   print(paste("selected", his_fili))
                 })
  hbox_fltf_b$packStart(file_ch_fltfh)
  hbox_fltf_b$packStart(gtkLabel("Folder path:"),FALSE)
  file_ch_fltff <- gtkFileChooserButton("Select a folder...",
                                        "select-folder")
  file_ch_fltff$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_fltff, "selection-changed",
                 function(file_ch_fltff) {
                   fu_fili <<- file_ch_fltff$getFilename()     #  "<<-" making fu_fili global variable
                   print(paste("selected", fu_fili))
                 })
  hbox_fltf_b$packStart(file_ch_fltff)
  vbox_ch$packStart(hbox_fltf_b,expand = FALSE , fill = FALSE,10)
  frame_cdi$add(vbox_ch)

  ##### Starting and ending years for historic data ############################################
  hbox1_ncv <-gtkHBoxNew(FALSE,8)
  hbox1_ncv['spacing'] <-35
  hbox1_ncv$packStart(gtkLabel("Starting year for Historic Data:             "),FALSE)
  entry1 <- gtkEntry()
  hbox1_ncv$packStart(entry1)
  gtkEditableInsertText(entry1,"1970", position = 0)
  hbox1_ncv$packStart(gtkLabel("                Ending year for Historic Data:              "),FALSE)
  entry2 <- gtkEntry()
  hbox1_ncv$packStart(entry2)
  gtkEditableInsertText(entry2,"2005", position = 0)
  vbox_ch$packStart(hbox1_ncv,expand = FALSE , fill = FALSE)

  ##### Starting and ending years for historic data ############################################
  ##### starting and ending years for future data ############################################
  hbox1_nfcv <-gtkHBoxNew(FALSE,8)
  hbox1_nfcv['spacing'] <-40
  hbox1_nfcv$packStart(gtkLabel("Starting year for Future Data:             "),FALSE)
  entry3 <- gtkEntry()
  hbox1_nfcv$packStart(entry3)
  gtkEditableInsertText(entry3,"2006", position = 0)
  hbox1_nfcv$packStart(gtkLabel("                Ending year for Future Data:              "),FALSE)
  entry4 <- gtkEntry()
  hbox1_nfcv$packStart(entry4)
  gtkEditableInsertText(entry4,"2040", position = 0)
  vbox_ch$packStart(hbox1_nfcv,expand = FALSE , fill = FALSE,10)
  ##### starting and ending years for future data ############################################

  ##### To Keep the frame for  Output files Information
  frame_opfi = gtkFrameNew("OUTPUT FILES INFORAMTION")
  vbox_b$packStart(frame_opfi,expand = FALSE , fill = FALSE,10)
  vbox_op<-gtkVBoxNew(FALSE,8)
  ## Code for outputfile folder location
  hbox_opfl_n <-gtkHBoxNew(FALSE,8)
  hbox_opfl_n['spacing'] <-118
  hbox_opfl_n$packStart(gtkLabel("   Ouput Folder Location:"),FALSE)
  file_ch_opfl <- gtkFileChooserButton("Select a folder...",
                                       "select-folder")
  file_ch_opfl$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_opfl, "selection-changed",
                 function(file_ch_opfl) {
                   op_loc <<- file_ch_opfl$getFilename()     # "<<-" making op_loc global variable
                   print(paste("selected", op_loc))
                 })
  hbox_opfl_n$packStart(file_ch_opfl)
  vbox_op$packStart(hbox_opfl_n,expand = FALSE , fill = FALSE,10)
  ## Code for outputfile folder location

  ##### Code for selection of output folder names for historic amd future ############################################
  hbox1_opfn <-gtkHBoxNew(FALSE,8)
  hbox1_opfn['spacing'] <-83
  hbox1_opfn$packStart(gtkLabel("   Output Folder Name:              "),FALSE)
  entry5 <- gtkEntry()
  hbox1_opfn$packStart(entry5)
  gtkEditableInsertText(entry5,"Delta_Corrected_Data", position = 0)
  vbox_op$packStart(hbox1_opfn,expand = FALSE , fill = FALSE,10)
  ##### Number of climate variables information ############################################

  ## Code for ouput file starting name  selection ##
  hbox1_osn <-gtkHBoxNew(FALSE,8)
  hbox1_osn['spacing'] <-103
  hbox1_osn$packStart(gtkLabel("   Outputfile Starting String:"),FALSE)
  entry0 <- gtkEntry()
  hbox1_osn$packStart(entry0)
  gtkEditableInsertText(entry0,"WS", position = 0)
  vbox_op$packStart(hbox1_osn,expand = FALSE , fill = FALSE,10)

  frame_opfi$add(vbox_op)

  ## Code for ouput file starting name  selection ##

  ### Code for selection of all input signals and writing them to variables ##############
  hbox2_n <-gtkHBoxNew(TRUE,8)
  button_run_n1 <- gtkButton("Delta Change Method")
  hbox2_n$packStart(button_run_n1, expand = FALSE , fill = FALSE,10)
  vbox_b$packStart(hbox2_n,expand = FALSE , fill = FALSE,10)
  frame_bias$add(vbox_b)
  bias_window$add(frame_bias)
  gSignalConnect(button_run_n1,"clicked", function(button){  styrhis <- as.numeric(entry1$getText())
  enyrhis  <- as.numeric(entry2$getText())
  styrfu  <- as.numeric(entry3$getText())
  enyrfu   <- as.numeric(entry4$getText())
  opfo_his<-entry5$getText()
  nasstp <-entry0$getText()
  print(styrhis)
  print(enyrhis)
  print(styrfu)
  print(enyrfu)
  print(nasstp)
  print(wdname)
  print(gpfile)
  print(fpath1)
  print(gpfile_fu)
  print(fpath2)
  print(gpfile_obs)
  print(fpath3)
  print(his_fili)
  print(fu_fili)
  print(op_loc)
  deltachange(wdname,gpfile,fpath1,gpfile_fu,fpath2,gpfile_obs,fpath3,his_fili,fu_fili,styrfu,enyrfu,op_loc,opfo_his,nasstp)
  })
  button_run_n2 <- gtkButton("Change Factor Method")
  hbox2_n$packStart(button_run_n2, expand = FALSE , fill = FALSE,10)
  vbox_b$packStart(hbox2_n,expand = FALSE , fill = FALSE,10)
  frame_bias$add(vbox_b)
  bias_window$add(frame_bias)
  gSignalConnect(button_run_n2,"clicked", function(button){  styrhis <- as.numeric(entry1$getText())
  enyrhis  <- as.numeric(entry2$getText())
  opfo_his<-entry5$getText()
  styrfu  <- as.numeric(entry3$getText())
  enyrfu   <- as.numeric(entry4$getText())
  nasstp <-entry0$getText()
  print(styrhis)
  print(enyrhis)
  print(styrfu)
  print(enyrfu)
  print(nasstp)
  print(wdname)
  print(gpfile)
  print(fpath1)
  print(gpfile_fu)
  print(fpath2)
  print(gpfile_obs)
  print(fpath3)
  print(his_fili)
  print(fu_fili)
  print(op_loc)
  changefactormethod(wdname,gpfile,fpath1,gpfile_fu,fpath2,gpfile_obs,fpath3,his_fili,fu_fili,styrhis,enyrhis,styrfu,enyrfu,op_loc,opfo_his,nasstp)
  })
  button_run_n3 <- gtkButton("Direct Change Method")
  hbox2_n$packStart(button_run_n3, expand = FALSE , fill = FALSE,10)
  vbox_b$packStart(hbox2_n,expand = FALSE , fill = FALSE,10)
  frame_bias$add(vbox_b)
  bias_window$add(frame_bias)
  gSignalConnect(button_run_n3,"clicked", function(button){  styrhis <- as.numeric(entry1$getText())
  enyrhis  <- as.numeric(entry2$getText())
  styrfu  <- as.numeric(entry3$getText())
  enyrfu   <- as.numeric(entry4$getText())
  opfo_his<-entry5$getText()
  nasstp <-entry0$getText()
  print(styrhis)
  print(enyrhis)
  print(styrfu)
  print(enyrfu)
  print(nasstp)
  print(wdname)
  print(gpfile)
  print(fpath1)
  print(gpfile_fu)
  print(fpath2)
  print(gpfile_obs)
  print(fpath3)
  print(his_fili)
  print(fu_fili)
  print(op_loc)
  directchangemethod(wdname,gpfile,fpath1,gpfile_fu,fpath2,gpfile_obs,fpath3,his_fili,fu_fili,styrhis,enyrhis,styrfu,enyrfu,op_loc,opfo_his,nasstp)
  })


  bias_window$show()
}
gSignalConnect(button_d,"clicked", function(button_c){delta_correction()})

vis_fun <-function(){
  window <- gtkWindow(show = FALSE)
  window$setTitle("Visualization Tool")
  frame <- gtkFrameNew()
  vbox <- gtkVBoxNew(FALSE,8)
  vbox$setBorderWidth(24)
  ##Code for working directory selection##
  hbox_swd <-gtkHBoxNew(FALSE,8)
  hbox_swd['spacing'] <-80
  hbox_swd$packStart(gtkLabel("   Select the Working Directory:"),FALSE)
  file_ch_swd <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  gSignalConnect(file_ch_swd, "selection-changed",
                 function(file_ch_swd) {
                   wdname <<- file_ch_swd$getFilename()       # "<<-" making wdname global variable
                   print(paste("selected", wdname))
                 })
  hbox_swd$packStart(file_ch_swd)
  vbox$packStart(hbox_swd,expand = FALSE , fill = FALSE,10)
  ##Code for working directory selection##
  ##Code for Input Data Frame##
  frame_ip = gtkFrameNew("Input Information")
  vbox$packStart(frame_ip,expand = TRUE , fill = TRUE,10)
  vbox_ch<-gtkVBoxNew(TRUE,8)
  hbox_csv <-gtkHBoxNew(FALSE,8)
  hbox_csv['spacing'] <-50
  hbox_csv$packStart(gtkLabel("  Climate data file(*.csv):                    "),FALSE)
  file_csv <- gtkFileChooserButton("Select a file...",
                                   "select-file")
  file_csv$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_csv, "selection-changed",
                 function(file_csv) {
                   csvfile <<- file_csv$getFilename()     # "<<-" making ncfile global variable
                   print(paste("selected", csvfile))
                 })
  hbox_csv$packStart(file_csv)
  vbox_ch$packStart(hbox_csv,expand = TRUE , fill = TRUE,10)
  hbox_shp <-gtkHBoxNew(FALSE,8)
  hbox_shp['spacing'] <-50
  hbox_shp$packStart(gtkLabel("  Region Boundary Shapefile(*.shp):"),FALSE)
  file_shp <- gtkFileChooserButton("Select a file...",
                                   "select-file")
  file_shp$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_shp, "selection-changed",
                 function(file_shp) {
                   shpfile <<- file_shp$getFilename()     # "<<-" making ncfile global variable
                   print(paste("selected", shpfile))
                 })
  hbox_shp$packStart(file_shp)
  vbox_ch$packStart(hbox_shp,expand = TRUE , fill = TRUE,10)
  frame_ip$add(vbox_ch)

  hbox1 <- gtkHBoxNew(FALSE,8)
  hbox1['spacing'] <- 20
  hbox1$packStart(gtkLabel("  Enter start latitude value:    "),FALSE)
  entry1 <- gtkEntry()
  hbox1$packStart(entry1)
  hbox1$packStart(gtkLabel("Enter end latitude value:    "),FALSE)
  entry2<-gtkEntry()
  hbox1$packStart(entry2)
  vbox_ch$packStart(hbox1,expand=FALSE,fill=FALSE,10)
  hbox2 <- gtkHBoxNew(FALSE,8)
  hbox2['spacing'] <- 20
  hbox2$packStart(gtkLabel("  Enter start longitude value:"),FALSE)
  entry3 <- gtkEntry()
  hbox2$packStart(entry3)
  hbox2$packStart(gtkLabel("Enter end longitude value:"),FALSE)
  entry4 <- gtkEntry()
  hbox2$packStart(entry4)
  vbox_ch$packStart(hbox2,expand=FALSE,fill=FALSE,10)
  frame$add(vbox)
  hbox_p <- gtkHBoxNew(FALSE,8)
  hbox_p['spacing'] <- 40
  hbox_p$packStart(gtkLabel("  Enter Parameter Name:"),FALSE)
  entryp <- gtkEntry()
  hbox_p$packStart(entryp)
  vbox_ch$packStart(hbox_p,expand=FALSE,fill=FALSE,10)
  frame$add(vbox)


  hbox3<-gtkHBoxNew(TRUE,8)
  button_run <- gtkButton("Multi Plot")
  hbox3$packStart(button_run, expand = FALSE , fill = FALSE,10)
  vbox$packStart(hbox3,expand = FALSE , fill = FALSE,10)
  vbox$add(button_run)
  button_run <- gtkButton("            Multi Plot
                          (with common legend)")
  hbox3$packStart(button_run, expand = FALSE , fill = FALSE,10)
  vbox$packStart(hbox3,expand = FALSE , fill = FALSE,10)
  vbox$add(button_run)
  button_run <- gtkButton("Animation")
  hbox3$packStart(button_run, expand = FALSE , fill = FALSE,10)
  vbox$packStart(hbox3,expand = FALSE , fill = FALSE,10)
  vbox$add(button_run)


  frame$add(vbox)
  window$add(frame)
  gSignalConnect(button_run,"clicked",function(button){ s_lat <- as.numeric(entry1$getText())
  e_lat <- as.numeric(entry2$getText())
  s_lon <- as.numeric(entry3$getText())
  e_lon <- as.numeric(entry4$getText())
  parameter<-entryp$getText()
  print(s_lat)
  print(e_lat)
  print(s_lon)
  print(e_lon)
  print(wdname)
  print(csvfile)
  print(shpfile)
  visualize(wdname, csvfile,shpfile,s_lat, e_lat, s_lon, e_lon) })
  window$show()
}
gSignalConnect(button_e,"clicked", function(button_c){vis_fun()})



narccapwinfun <- function(){
  ########### NARCCAP MODEL GUI CODE
  narccap_window<-gtkWindow(show=FALSE)
  narccap_window$set(title="NARCCAP DATABASE CONVERSION TOOL")
  frame_narccap =gtkFrameNew()
  vbox_n = gtkVBoxNew(FALSE, 8)
  vbox_n$setBorderWidth(24)

  ### Horizointal box and its contents to set the working Directory########
  hbox_swd_n <-gtkHBoxNew(FALSE,8)
  hbox_swd_n['spacing'] <-90
  hbox_swd_n$packStart(gtkLabel("   Select the Working Directory:"),FALSE)
  file_ch_swd <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  gSignalConnect(file_ch_swd, "selection-changed",
                 function(file_ch_swd) {
                   wdname <<- file_ch_swd$getFilename()       # "<<-" making wdname global variable
                   print(paste("selected", wdname))
                 })
  hbox_swd_n$packStart(file_ch_swd)
  vbox_n$packStart(hbox_swd_n,expand = FALSE , fill = FALSE,10)

  ####### H-Box close for set the working directory##############
  ##### To Keep the frame for Climate Date sets Information
  frame_cdi = gtkFrameNew("CLIMATE DATA SETS INFORAMTION")
  vbox_n$packStart(frame_cdi,expand = TRUE , fill = TRUE,10)
  vbox_ch<-gtkVBoxNew(TRUE,8)
  ## Horizointal box and its contents to select the watershed climate grid points txt file###
  hbox_gpf_n <-gtkHBoxNew(FALSE,8)
  hbox_gpf_n['spacing'] <-30
  hbox_gpf_n$packStart(gtkLabel("   Watershed climate grid points file(*.txt):"),FALSE)
  file_ch_gpf <- gtkFileChooserButton("Select a file...",
                                      "select-file")
  file_ch_gpf$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_gpf, "selection-changed",
                 function(file_ch_gpf) {
                   gpfile <<- file_ch_gpf$getFilename()     # "<<-" making gpfile global variable
                   print(paste("selected", gpfile))
                 })
  hbox_gpf_n$packStart(file_ch_gpf)
  vbox_ch$packStart(hbox_gpf_n,expand = TRUE , fill = TRUE,10)
  ################# code completes -H-Box climate grid points txt file ########################################


  #*****************Code for adding the files list text file  for present and future **********************#
  hbox_fltf_n <-gtkHBoxNew(FALSE,8)
  hbox_fltf_n['spacing'] <-20
  hbox_fltf_n$packStart(gtkLabel("   File List Text File(*.txt):            "),FALSE)
  hbox_fltf_n$packStart(gtkLabel("Historic:"),FALSE)
  file_ch_fltfh <- gtkFileChooserButton("Select a file...",
                                        "select-file")
  file_ch_fltfh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_fltfh, "selection-changed",
                 function(file_ch_fltfh) {
                   his_fili <<- file_ch_fltfh$getFilename()     # "<<-" making his_fili global variable

                   print(paste("selected", his_fili))
                 })
  hbox_fltf_n$packStart(file_ch_fltfh)
  hbox_fltf_n$packStart(gtkLabel("Future:"),FALSE)
  file_ch_fltff <- gtkFileChooserButton("Select a file...",
                                        "select-file")
  file_ch_fltff$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_fltff, "selection-changed",
                 function(file_ch_fltff) {
                   fu_fili <<- file_ch_fltff$getFilename()     #  "<<-" making fu_fili global variable

                   print(paste("selected", fu_fili))
                 })
  hbox_fltf_n$packStart(file_ch_fltff)
  vbox_ch$packStart(hbox_fltf_n,expand = FALSE , fill = FALSE)

  #*****************Code for adding the files list text file  for present and future **********************#

  #*****************Code for adding the folder path for climate files ****************************************#
  hbox_cdff_n <-gtkHBoxNew(FALSE,8)
  hbox_cdff_n['spacing'] <-20
  hbox_cdff_n$packStart(gtkLabel("   Climate Date Files Folder:       "),FALSE)
  hbox_cdff_n$packStart(gtkLabel("Historic:"),FALSE)
  file_ch_cdffh <- gtkFileChooserButton("Select a folder...",
                                        "select-folder")
  file_ch_cdffh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_cdffh, "selection-changed",
                 function(file_ch_cdffh) {
                   his_dtfo <<- file_ch_cdffh$getFilename()   # "<<-" making his_dtfo global variable
                   print(paste("selected", his_dtfo))
                 })
  hbox_cdff_n$packStart(file_ch_cdffh)
  hbox_cdff_n$packStart(gtkLabel("Future:"),FALSE)
  file_ch_cdfff <- gtkFileChooserButton("Select a folder...",
                                        "select-folder")
  file_ch_cdfff$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_cdfff, "selection-changed",
                 function(file_ch_cdfff) {
                   fu_dtfo <<- file_ch_cdfff$getFilename()      # "<<-" making fu_dtfo global variable
                   print(paste("selected", fu_dtfo))
                 })
  hbox_cdff_n$packStart(file_ch_cdfff)
  vbox_ch$packStart(hbox_cdff_n,expand = FALSE , fill = FALSE)
  frame_cdi$add(vbox_ch)
  #*****************Code for adding the folder path for climate files ****************************************#

  ##### Number of climate variables information ############################################
  hbox1_ncv <-gtkHBoxNew(FALSE,8)
  hbox1_ncv['spacing'] <-20
  hbox1_ncv$packStart(gtkLabel("   Number of Climate Variables:"),FALSE)
  hbox1_ncv$packStart(gtkLabel("Historic:"),FALSE)
  entry1 <- gtkEntry()
  hbox1_ncv$packStart(entry1)
  gtkEditableInsertText(entry1,"3", position = 0)
  hbox1_ncv$packStart(gtkLabel("Future:"),FALSE)
  entry2 <- gtkEntry()
  hbox1_ncv$packStart(entry2)
  gtkEditableInsertText(entry2,"3", position = 0)
  vbox_ch$packStart(hbox1_ncv,expand = FALSE , fill = FALSE,10)
  ##### Number of climate variables information ############################################

  ##### Number of files for each climate variable ############################################
  hbox1_nfcv <-gtkHBoxNew(FALSE,8)
  hbox1_nfcv['spacing'] <-20
  hbox1_nfcv$packStart(gtkLabel("   Number of Files for each
                                Climate Variable:              "),FALSE)
  hbox1_nfcv$packStart(gtkLabel("Historic:"),FALSE)
  entry3 <- gtkEntry()
  hbox1_nfcv$packStart(entry3)
  gtkEditableInsertText(entry3,"7", position = 0)
  hbox1_nfcv$packStart(gtkLabel("Future:"),FALSE)
  entry4 <- gtkEntry()
  hbox1_nfcv$packStart(entry4)
  gtkEditableInsertText(entry4,"7", position = 0)
  vbox_ch$packStart(hbox1_nfcv,expand = FALSE , fill = FALSE,10)
  ##### Number of climate variables information ############################################

  ##### Codes for Climate Data Sets Information #########################



  ##### To Keep the frame for  Output files Information
  frame_opfi = gtkFrameNew("OUTPUT FILES INFORAMTION")
  vbox_n$packStart(frame_opfi,expand = FALSE , fill = FALSE,10)
  vbox_op<-gtkVBoxNew(FALSE,8)
  ## Code for outputfile folder location
  hbox_opfl_n <-gtkHBoxNew(FALSE,8)
  hbox_opfl_n['spacing'] <-118
  hbox_opfl_n$packStart(gtkLabel("   Ouput Folder Location:"),FALSE)
  file_ch_opfl <- gtkFileChooserButton("Select a folder...",
                                       "select-folder")
  file_ch_opfl$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_opfl, "selection-changed",
                 function(file_ch_opfl) {
                   op_loc <<- file_ch_opfl$getFilename()     # "<<-" making op_loc global variable
                   print(paste("selected", op_loc))
                 })
  hbox_opfl_n$packStart(file_ch_opfl)
  vbox_op$packStart(hbox_opfl_n,expand = FALSE , fill = FALSE,10)
  ## Code for outputfile folder location

  ##### Code for selection of output folder names for historic amd future ############################################
  hbox1_opfn <-gtkHBoxNew(FALSE,8)
  hbox1_opfn['spacing'] <-20
  hbox1_opfn$packStart(gtkLabel("   Output Folder Name:              "),FALSE)
  hbox1_opfn$packStart(gtkLabel("Historic:"),FALSE)
  entry5 <- gtkEntry()
  hbox1_opfn$packStart(entry5)
  gtkEditableInsertText(entry5,"Historic", position = 0)
  hbox1_opfn$packStart(gtkLabel("Future:"),FALSE)
  entry6 <- gtkEntry()
  hbox1_opfn$packStart(entry6)
  gtkEditableInsertText(entry6,"Future", position = 0)
  vbox_op$packStart(hbox1_opfn,expand = FALSE , fill = FALSE,10)
  ##### Number of climate variables information ############################################

  ## Code for ouput file starting name  selection ##
  hbox1_osn <-gtkHBoxNew(FALSE,8)
  hbox1_osn['spacing'] <-103
  hbox1_osn$packStart(gtkLabel("   Outputfile Starting String:"),FALSE)
  entry0 <- gtkEntry()
  hbox1_osn$packStart(entry0)
  gtkEditableInsertText(entry0,"WS", position = 0)
  vbox_op$packStart(hbox1_osn,expand = FALSE , fill = FALSE,10)
  frame_opfi$add(vbox_op)
  ## Code for ouput file starting name  selection ##

  ### Code for selection of all input signals and writing them to variables ##############
  hbox2_n <-gtkHBoxNew(TRUE,8)
  button_run_n <- gtkButton("RUN")
  hbox2_n$packStart(button_run_n, expand = FALSE , fill = FALSE,10)
  vbox_n$packStart(hbox2_n,expand = FALSE , fill = FALSE,10)
  frame_narccap$add(vbox_n)
  narccap_window$add(frame_narccap)
  gSignalConnect(button_run_n,"clicked", function(button){  numvar_his <- as.numeric(entry1$getText())
  numvar_fu  <- as.numeric(entry2$getText())
  numfi_his  <- as.numeric(entry3$getText())
  numfi_fu   <- as.numeric(entry4$getText())
  opfo_his<-entry5$getText()
  opfo_fu<-entry6$getText()

  nasstp <-entry0$getText()
  print(numvar_his)
  print(numvar_fu)
  print(numfi_his)
  print(numfi_fu)
  print(nasstp)
  print(wdname)
  print(gpfile)
  print(his_fili)
  print(fu_fili)
  print(his_dtfo)
  print(fu_dtfo)
  print(op_loc)
  print(opfo_his)
  print(opfo_fu)
  clim_swat_convert(wdname,gpfile,his_fili,fu_fili,his_dtfo,fu_dtfo,numvar_his,numvar_fu,
                    numfi_his,numfi_fu, op_loc, opfo_his, opfo_fu, nasstp)
  })
  narccap_window$show()

} # closer for narccapwinfun()


############################# GUI WINDOW CODE FOR NARCCAP ################################

############################### GUI WINDOW FOR CMIP5 #############################
CMIP5winfun <- function(){
  CMIP5_window<-gtkWindow(show=FALSE)
  CMIP5_window$set(title="CMIP5 DATABASE CONVERSION TOOL")
  frame_CMIP5 =gtkFrameNew()
  vbox_c = gtkVBoxNew(FALSE, 8)
  vbox_c$setBorderWidth(24)
  ###Horizontal Box and its contents for selection  of working directory###
  hbox_swd_c <-gtkHBoxNew(FALSE,8)
  hbox_swd_c['spacing'] <-60
  hbox_swd_c$packStart(gtkLabel("   Select the Working Directory:"),FALSE)
  file_c_swd <- gtkFileChooserButton("Select a folder...",
                                     "select-folder")
  gSignalConnect(file_c_swd, "selection-changed",
                 function(file_c_swd) {
                   wdname <<- file_c_swd$getFilename()       # "<<-" making wdname global variable
                   print(paste("selected", wdname))
                 })
  hbox_swd_c$packStart(file_c_swd)
  vbox_c$packStart(hbox_swd_c,expand = FALSE , fill = FALSE,10)

  ####### H-Box close for set the working directory##############
  ##### To Keep the frame for Projections and Watershed Information
  frame_pwi = gtkFrameNew()
  vbox_c$packStart(frame_pwi,expand = TRUE , fill = TRUE,10)
  vbox_ch1<-gtkVBoxNew(TRUE,8)
  ### Horizointal box and its contents to select the watershed climate grid points txt file###
  hbox_pfl_c<-gtkHBoxNew(FALSE,8)
  hbox_pfl_c['spacing']<-80
  hbox_pfl_c$packStart(gtkLabel("   Projections File list(*.txt):"),FALSE)
  file_ch_pfl<-gtkFileChooserButton("Select a file...",
                                    "select-file")
  gSignalConnect(file_ch_pfl, "selection-changed",
                 function(file_ch_pfl) {
                   prfile <<- file_ch_pfl$getFilename()     # "<<-" making prfile global variable
                   print(paste("selected", prfile))
                 })
  hbox_pfl_c$packStart(file_ch_pfl)
  vbox_ch1$packStart(hbox_pfl_c,expand = TRUE , fill = TRUE,10)
  frame_pwi$add(vbox_ch1)
  ################# code completes -H-Box Projection File list txt file ########################################
  ## Code for No of Projections for Simulations ##
  hbox_ps <-gtkHBoxNew(FALSE,8)
  hbox_ps['spacing'] <-65
  hbox_ps$packStart(gtkLabel("   Projections for Simulations:"),FALSE)
  entry0<-gtkEntry()
  hbox_ps$packStart(entry0)
  vbox_ch1$packStart(hbox_ps,expand = FALSE , fill = FALSE,10)
  frame_pwi$add(vbox_ch1)
  ## Code for No of Projections for simulatons ##

  ## Code for Watershed short name to come in output filenames ##
  hbox_wsn <-gtkHBoxNew(FALSE,8)
  hbox_wsn['spacing'] <-85
  hbox_wsn$packStart(gtkLabel("   Watershed Short Name:"),FALSE)
  entry1 <- gtkEntry()
  hbox_wsn$packStart(entry1)
  vbox_ch1$packStart(hbox_wsn,expand = FALSE , fill = FALSE,10)
  frame_pwi$add(vbox_ch1)
  ## Code for Watershed Short Name complete ##

  ## Code for Watershed Grid Point File ##
  hbox_wgp <-gtkHBoxNew(FALSE,8)
  hbox_wgp['spacing'] <-45
  hbox_wgp$packStart(gtkLabel("   Watershed Grid Point file(*.txt):"),FALSE)
  file_c_wgp <- gtkFileChooserButton("Select a file...",
                                     "select-file")
  gSignalConnect(file_c_wgp, "selection-changed",
                 function(file_c_wgp) {
                   wgpfile <<- file_c_wgp$getFilename()     # "<<-" making wgpfile global variable
                   print(paste("selected", wgpfile))
                 })

  hbox_wgp$packStart(file_c_wgp)
  vbox_ch1$packStart(hbox_wgp,expand = FALSE , fill = FALSE,10)
  frame_pwi$add(vbox_ch1)
  ## Code for Watershed Grid Point File ##

  ## Code for frame containing CMIP-5 Climate Variable Information ##
  frame_cvi = gtkFrameNew("CMIP-5 CLIMATE VARIABLE INFORMATION")
  vbox_c$packStart(frame_cvi,expand = TRUE , fill = TRUE,10)
  vbox_ch1<-gtkVBoxNew(TRUE,8)
  ### Horizointal box for temperature and precipitation data ncdf file###
  hbox_maxt<-gtkHBoxNew(FALSE,8)
  hbox_maxt['spacing']<-45
  hbox_maxt$packStart(gtkLabel("   Maximum Temperature(*.ncdf):"),FALSE)
  file_ch_maxt<-gtkFileChooserButton("Select a file...","select-file")
  gSignalConnect(file_ch_maxt, "selection-changed",
                 function(file_ch_maxt) {
                   maxtfile <<- file_ch_maxt$getFilename()     # "<<-" making maxtfile global variable
                   print(paste("selected", maxtfile))
                 })
  hbox_maxt$packStart(file_ch_maxt)
  vbox_ch1$packStart(hbox_maxt,expand = TRUE , fill = TRUE,10)
  frame_cvi$add(vbox_ch1)

  hbox_mint<-gtkHBoxNew(FALSE,8)
  hbox_mint['spacing']<-45
  hbox_mint$packStart(gtkLabel("   Minimum Temperature(*.ncdf):"),FALSE)
  file_ch_mint<-gtkFileChooserButton("Select a file...","select-file")
  gSignalConnect(file_ch_mint, "selection-changed",
                 function(file_ch_mint) {
                   mintfile <<- file_ch_mint$getFilename()     # "<<-" making mintfile global variable
                   print(paste("selected", mintfile))
                 })
  hbox_mint$packStart(file_ch_mint)
  vbox_ch1$packStart(hbox_mint,expand = TRUE , fill = TRUE,10)
  frame_cvi$add(vbox_ch1)

  hbox_ppt<-gtkHBoxNew(FALSE,8)
  hbox_ppt['spacing']<-100
  hbox_ppt$packStart(gtkLabel("   Precipitation(*.ncdf):"),FALSE)
  file_ch_ppt<-gtkFileChooserButton("Select a file...","select-file")
  gSignalConnect(file_ch_ppt, "selection-changed",
                 function(file_ch_ppt) {
                   pptfile <<- file_ch_ppt$getFilename()     # "<<-" making pptfile global variable
                   print(paste("selected", pptfile))
                 })
  hbox_ppt$packStart(file_ch_ppt)
  vbox_ch1$packStart(hbox_ppt,expand = TRUE , fill = TRUE,10)
  frame_cvi$add(vbox_ch1)
  ### Horizointal box for temperature and precipitation data ncdf file-completed###

  ## Code For Output Folder Location ##
  hbox_opfl_c <-gtkHBoxNew(FALSE,8)
  hbox_opfl_c['spacing'] <-90
  hbox_opfl_c$packStart(gtkLabel("   Ouput Folder Location:"),FALSE)
  file_ch_opfl <- gtkFileChooserButton("Select a folder...",
                                       "select-folder")
  gSignalConnect(file_ch_opfl, "selection-changed",
                 function(file_ch_opfl) {
                   op_loc <<- file_ch_opfl$getFilename()     # "<<-" making op_loc global variable
                   print(paste("selected", op_loc))
                 })
  hbox_opfl_c$packStart(file_ch_opfl)
  vbox_c$packStart(hbox_opfl_c,expand = FALSE , fill = FALSE,10)
  ## Code For Output Folder Location ##

  ### Code for selection of all input signals and writing them to variables ###
  hbox2_c <-gtkHBoxNew(TRUE,8)
  button_run_c <- gtkButton("RUN")
  hbox2_c$packStart(button_run_c, expand = FALSE , fill = FALSE,10)
  vbox_c$packStart(hbox2_c,expand = FALSE , fill = FALSE,10)
  frame_CMIP5$add(vbox_c)
  CMIP5_window$add(frame_CMIP5)
  gSignalConnect(button_run_c,"clicked", function(button){ num_pr<-entry0$getText()
  ws_shname<-entry1$getText()
  print(wdname)
  print(prfile)
  print(wgpfile)
  print(maxtfile)
  print(mintfile)
  print(pptfile)
  print(num_pr)
  print(ws_shname)
  cmip_tool(wdname,prfile,num_pr,ws_shname,wgpfile,maxtfile,mintfile,pptfile,op_loc)
  })

  CMIP5_window$show()
} # close for the CMIP5winfun()


cordex <- function(){

  narccap_window<-gtkWindow(show=FALSE)
  narccap_window$set(title="CORDEX DATABASE CONVERSION TOOL")
  frame_narccap =gtkFrameNew()
  vbox_n = gtkVBoxNew(FALSE, 8)
  vbox_n$setBorderWidth(24)

  ### Horizointal box and its contents to set the working Directory########
  hbox_swd_n <-gtkHBoxNew(FALSE,8)
  hbox_swd_n['spacing'] <-90
  hbox_swd_n$packStart(gtkLabel("   Select the Working Directory:"),FALSE)
  file_ch_swd <- gtkFileChooserButton("Select a folder...",
                                      "select-folder")
  gSignalConnect(file_ch_swd, "selection-changed",
                 function(file_ch_swd) {
                   wdname <<- file_ch_swd$getFilename()       # "<<-" making wdname global variable
                   print(paste("selected", wdname))
                 })
  hbox_swd_n$packStart(file_ch_swd)
  vbox_n$packStart(hbox_swd_n,expand = FALSE , fill = FALSE,10)

  ####### H-Box close for set the working directory##############
  ##### To Keep the frame for Climate Date sets Information
  frame_cdi = gtkFrameNew("CLIMATE DATA SETS INFORAMTION")
  vbox_n$packStart(frame_cdi,expand = TRUE , fill = TRUE,10)
  vbox_ch<-gtkVBoxNew(TRUE,8)
  ## Horizointal box and its contents to select the watershed climate grid points txt file###
  hbox_gpf_n <-gtkHBoxNew(FALSE,8)
  hbox_gpf_n['spacing'] <-35
  hbox_gpf_n$packStart(gtkLabel("   Watershed climate grid points file(*.txt):"),FALSE)
  file_ch_gpf <- gtkFileChooserButton("Select a file...",
                                      "select-file")
  file_ch_gpf$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_gpf, "selection-changed",
                 function(file_ch_gpf) {
                   gpfile <<- file_ch_gpf$getFilename()     # "<<-" making gpfile global variable
                   print(paste("selected", gpfile))
                 })
  hbox_gpf_n$packStart(file_ch_gpf)
  vbox_ch$packStart(hbox_gpf_n,expand = TRUE , fill = TRUE,10)
  ################# code completes -H-Box climate grid points txt file ########################################


  #*****************Code for adding the files list text file  for present and future **********************#
  hbox_fltf_n <-gtkHBoxNew(FALSE,8)
  hbox_fltf_n['spacing'] <-90
  hbox_fltf_n$packStart(gtkLabel("   File List Text File(*.txt):            "),FALSE)
  ##hbox_fltf_n$packStart(gtkLabel("Historic:"),FALSE)
  file_ch_fltfh <- gtkFileChooserButton("Select a file...",
                                        "select-file")
  file_ch_fltfh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_fltfh, "selection-changed",
                 function(file_ch_fltfh) {
                   his_fili <<- file_ch_fltfh$getFilename()     # "<<-" making his_fili global variable

                   print(paste("selected", his_fili))
                 })
  hbox_fltf_n$packStart(file_ch_fltfh)

  vbox_ch$packStart(hbox_fltf_n,expand = FALSE , fill = FALSE)

  #*****************Code for adding the files list text file  for present and future **********************#

  #*****************Code for adding the folder path for climate files ****************************************#
  hbox_cdff_n <-gtkHBoxNew(FALSE,8)
  hbox_cdff_n['spacing'] <-90
  hbox_cdff_n$packStart(gtkLabel("   Climate Date Files Folder:       "),FALSE)
  file_ch_cdffh <- gtkFileChooserButton("Select a folder...",
                                        "select-folder")
  file_ch_cdffh$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_cdffh, "selection-changed",
                 function(file_ch_cdffh) {
                   his_dtfo <<- file_ch_cdffh$getFilename()   # "<<-" making his_dtfo global variable
                   print(paste("selected", his_dtfo))
                 })
  hbox_cdff_n$packStart(file_ch_cdffh)

  vbox_ch$packStart(hbox_cdff_n,expand = FALSE , fill = FALSE)
  frame_cdi$add(vbox_ch)
  #*****************Code for adding the folder path for climate files ****************************************#

  ##### Number of climate variables information ############################################
  hbox1_ncv <-gtkHBoxNew(FALSE,8)
  hbox1_ncv['spacing'] <-90
  hbox1_ncv$packStart(gtkLabel("   Number of Climate Variables:"),FALSE)
  entry1 <- gtkEntry()
  hbox1_ncv$packStart(entry1)
  gtkEditableInsertText(entry1,"3", position = 0)
  vbox_ch$packStart(hbox1_ncv,expand = FALSE , fill = FALSE,10)
  ##### Number of climate variables information ############################################

  ##### Number of files for each climate variable ############################################
  hbox1_nfcv <-gtkHBoxNew(FALSE,8)
  hbox1_nfcv['spacing'] <-90
  hbox1_nfcv$packStart(gtkLabel("   Number of Files for each
                                Climate Variable:              "),FALSE)
  entry3 <- gtkEntry()
  hbox1_nfcv$packStart(entry3)
  gtkEditableInsertText(entry3,"1", position = 0)
  vbox_ch$packStart(hbox1_nfcv,expand = FALSE , fill = FALSE,10)
  hbox_styr<-gtkHBoxNew(FALSE,8)
  hbox_styr['spacing']<-108
  hbox_styr$packStart(gtkLabel("   Enter Starting Date:            "),FALSE)
  entry4<-gtkEntry()
  hbox_styr$packStart(entry4)
  gtkEditableInsertText(entry4,"01/01/1970", position = 0)
  vbox_ch$packStart(hbox_styr,expand=FALSE,fill=FALSE,10)

  hbox_edyr<-gtkHBoxNew(FALSE,8)
  hbox_edyr['spacing']<-114
  hbox_edyr$packStart(gtkLabel("   Enter Ending Date:           "),FALSE)
  entry6<-gtkEntry()
  hbox_edyr$packStart(entry6)
  gtkEditableInsertText(entry6,"31/12/2005", position=0)
  vbox_ch$packStart(hbox_edyr,expand=FALSE,fill=FALSE,10)


  ##### Number of climate variables information ############################################

  ##### Codes for Climate Data Sets Information #########################



  ##### To Keep the frame for  Output files Information
  frame_opfi = gtkFrameNew("OUTPUT FILES INFORAMTION")
  vbox_n$packStart(frame_opfi,expand = FALSE , fill = FALSE,10)
  vbox_op<-gtkVBoxNew(FALSE,8)
  ## Code for outputfile folder location
  hbox_opfl_n <-gtkHBoxNew(FALSE,8)
  hbox_opfl_n['spacing'] <-118
  hbox_opfl_n$packStart(gtkLabel("   Ouput Folder Location:"),FALSE)
  file_ch_opfl <- gtkFileChooserButton("Select a folder...",
                                       "select-folder")
  file_ch_opfl$setCurrentFolder("C:/Users/Public/Documents")
  gSignalConnect(file_ch_opfl, "selection-changed",
                 function(file_ch_opfl) {
                   op_loc <<- file_ch_opfl$getFilename()     # "<<-" making op_loc global variable
                   print(paste("selected", op_loc))
                 })
  hbox_opfl_n$packStart(file_ch_opfl)
  vbox_op$packStart(hbox_opfl_n,expand = FALSE , fill = FALSE,10)
  ## Code for outputfile folder location

  ##### Code for selection of output folder names for historic amd future ############################################
  hbox1_opfn <-gtkHBoxNew(FALSE,8)
  hbox1_opfn['spacing'] <-85
  hbox1_opfn$packStart(gtkLabel("   Output Folder Name:              "),FALSE)
  entry5 <- gtkEntry()
  hbox1_opfn$packStart(entry5)
  gtkEditableInsertText(entry5,"Historic", position = 0)
  vbox_op$packStart(hbox1_opfn,expand = FALSE , fill = FALSE,10)
  ##### Number of climate variables information ############################################

  ## Code for ouput file starting name  selection ##
  hbox1_osn <-gtkHBoxNew(FALSE,8)
  hbox1_osn['spacing'] <-103
  hbox1_osn$packStart(gtkLabel("   Outputfile Starting String:"),FALSE)
  entry0 <- gtkEntry()
  hbox1_osn$packStart(entry0)
  gtkEditableInsertText(entry0,"WS", position = 0)
  vbox_op$packStart(hbox1_osn,expand = FALSE , fill = FALSE,10)
  frame_opfi$add(vbox_op)
  ## Code for ouput file starting name  selection ##

  ### Code for selection of all input signals and writing them to variables ##############
  hbox2_n <-gtkHBoxNew(TRUE,8)
  button_run_n <- gtkButton("RUN")
  hbox2_n$packStart(button_run_n, expand = FALSE , fill = FALSE,10)
  vbox_n$packStart(hbox2_n,expand = FALSE , fill = FALSE,10)
  frame_narccap$add(vbox_n)
  narccap_window$add(frame_narccap)
  gSignalConnect(button_run_n,"clicked", function(button){  numvar_his <- as.numeric(entry1$getText())
  numfi_his  <- as.numeric(entry3$getText())
  st_yr<-entry4$getText()
  ed_yr<-entry6$getText()
  opfo_his<-entry5$getText()
  nasstp <-entry0$getText()
  print(numvar_his)
  print(numfi_his)
  print(nasstp)
  print(wdname)
  print(gpfile)
  print(his_fili)
  print(his_dtfo)
  print(op_loc)
  print(opfo_his)
  print(st_yr)
  print(ed_yr)
  clim_swat_convert(wdname,gpfile,his_fili,his_dtfo,numvar_his,
                    numfi_his, op_loc,opfo_his,nasstp,st_yr,ed_yr)
  })
  narccap_window$show()
}

}
